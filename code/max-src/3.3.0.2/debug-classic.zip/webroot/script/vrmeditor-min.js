require(['MP'], function (MP) {
  MP.Events.onMpCoreLoaded = function () {
    var url = Browser.ParseURL(),
        readOnly = url.searchObject.ro == '1';

    //MP.Initialize({});
    Communication.SessionID = url.searchObject.id;
    Communication.MakeAllCompsDefault($('#AdminTabs'), false, true, false);

	// Request editor config first for core to properly initialize!
	Communication.CustomRequest("loadeditorcfg.max", function(r) {
		var cfgObj = {};
		try {
			if (r) {
				r = r.replace(/&(quot);/g, '"');
				cfgObj = $.parseJSON(r);
			};
		} catch (err) {
			Log.Add("LoadEditorCfg", err, Log.Type.Error, true);
		}
		
		$.extend(cfgObj, {webSocket: {systemApplication:"notifications"}});

		MP.Initialize(cfgObj);
	});

	if (window.ace) {
	    ace.require("ace/lib/fixoldbrowsers");
	    var cfg = ace.require("ace/config"),
	    	dom = ace.require("ace/lib/dom"),
	    	cmd = ace.require("ace/commands/default_commands"),
	    	parentOverflow;
	    
	    cfg.init();
	    cmd.commands.push({
	      name: "Toggle Fullscreen",
	      bindKey: "F11",
	      exec: function(editor) {
			// Fix for Chrome 60.0.3112.90 issue preventing advanced editors to display in full screen!
			var dlg = $(editor.container.offsetParent);
			if (!parentOverflow) {
				parentOverflow = dlg.css('overflow');
				dlg.css('overflow', 'visible');
			} else {
				dlg.css('overflow', parentOverflow);
				parentOverflow = '';
			}

	        dom.toggleCssClass(document.body, "fullScreen");
	        dom.toggleCssClass(editor.container, "fullScreen");

	        editor.resize();
	      }
	    },{
	      name: "Toggle Word Wrap",
	      bindKey: "Alt-W",
	      exec: function(editor) {
	        var b = !editor.session.getUseWrapMode();
	        editor.session.setUseWrapMode(b);
	        MP.Tools.Config.Editor.ace.wordWrap = b;
	      }
	    },{
	      name: "Remove doubled single quotes",
	      bindKey: "Alt-S",
	      exec: function(editor) {
	        editor.find("''")
	        editor.replaceAll("'");
	      }
	    },{
	      name: "Double single quotes",
	      bindKey: "Alt-D",
	      exec: function(editor) {
	        editor.find("'")
	        editor.replaceAll("''");
	      }
	    },{
	      name: "Online Help",
	      bindKey: "F1",
	      exec: function(editor) {
	        var pos = editor.selection.getCursor(),
	          tkn = editor.session.getTokenAt(pos.row, pos.column),
	          word = tkn.value.trim().toLowerCase(),
	          mode = editor.session.$modeId,
	          lng = mode.split("/").pop(),
	          wnd = "width=800,height=800,scrollbars=yes,resizable=yes,toolbar=no,location=no,menubar=no,status=no",
	          url;
	        
	        //"text", "sql", "javascript", "pascal", "xml", "json", "html", "css"
	        switch (lng) {
	          case 'pascal': url = '../../help/scripting.htm#' + word; break;
	          case 'sql': url = 'https://www.google.com/?gws_rd=ssl#q=mssql+' + word; break;
	          case 'text':
	          case 'xml':
	          case 'json': url = ''; break;
	          default: url = 'https://www.google.com/?gws_rd=ssl#q=' + lng + '+' + word; break;
	        }
	        if (url)
	          window.open(url, "StingrayHelp", wnd);
	      }
	    });
	};

	// Request editor last so core have time to initialize!
	Communication.EditorRequest(url.searchObject.templatename, readOnly, true);
  };
});
