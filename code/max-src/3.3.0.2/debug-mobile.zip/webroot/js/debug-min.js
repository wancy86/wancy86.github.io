/** @license
  Copyright (c) 2008-2016, Maximum Processing Inc, All Rights Reserved.
  
  BEGIN of Core JS Objects
*/
if (typeof jQuery === 'undefined') {
	throw new Error('Bootstrap\'s JavaScript requires jQuery');
}

if (typeof MP === 'undefined') {
	throw new Error('Missing MP root object!');
}

// Main enclosure
(function (window, document, $, undefined) {
	
	// Required modules
	var mp = window.MP,
		utils = mp.Utils,
		dialog = mp.Dialog,
		tools = mp.Tools,
		log = opener.MP.Log;

	var ver = '3.0.1.0',
		good = utils.FirstVersionSameOrAboveSecond(mp.StingrayJsVersion, ver);
	if (!good) {
		dialog.Error('Incorrect core version! MP core must be at least in version ' + ver);
		return;
	};

	// ReqList viewer
	var reqList = new function () {
		try {

			/* PRIVATE PROPERTIES */
			var logClassName = "reqList.",
				_wrapper,
				_reqTable = $([]),
				_reqID = 0,
				_lastReqList,			// the last RL sent from stingray
				_config = {};
			
			function iLog(Place, Message, Type, Silent) {
				log.Add(logClassName + Place, Message, Type, Silent);
			}
			function Entry(Name, Value) {
				this.Name = Name;
				this.Value = Value;
			}
			function FormatEntry(ent) {
				_reqID++;
				
				var le = $("<tr/>");
				le.append("<td class='index'>" + _reqID + "</td>");
				le.append("<td class='name'>" + ent.Name + "</td>");
				if (ent.Name == 'VRM-PG')
					le.append("<td class='wpValue'>" + ent.Value + "</td>");
				else {
					le.append("<td class='value'><code class='ReqList'/></td>");
					le.find("code").text(ent.Value);
				};

				return le;
			}
			function AddVarOfName(name) {
				if (!_config.filterVars)
					return true;
				
				var arr = _config.filter.split(" ");
				for (var i = 0; i < arr.length; i++) {
					var re = new RegExp(arr[i], "i");
					if (name.search(re) > -1)
						return true;
				};
				return false;
			}
			// Remove the oldest records to preserve system resources
			function EnsureLimit() {
				var cnt = _reqTable.find("tr").length;
				if (cnt > 1000) {
					var i = cnt - 1000;
					_reqTable.find("tr:gt(0):lt(" + i.toString() + ")").empty().remove();
				}
			}
			function filterBy(value) {
				iLog("filterBy", "Called: " + value);
					
				var rows = _reqTable.find("tr td.name").parent();
				if (!value) {
					rows.show();
				} else {
					var arr = value.split(" ");
					for (var r = 0; r < rows.length; r++) {
						var tr = $(rows[r]);
						var name = tr.find("td.name").text();
						var found = name == 'VRM-PG';

						if (!found) {
							for (var i = 0; i < arr.length; i++) {
								var re = new RegExp(arr[i], "i");
								if (name.search(re) > -1) {
									found = true;
									break;
								};
							};
						};
						if (found)
							tr.show()
						else
							tr.hide();
					};
				};
			}

			return {
			
				Enabled : false,
				Initialized : false,
				ExcludeVRMs : [],
				
				Initialize : function (cfgObj, lastXML) {
					try {
						cfgObj = cfgObj || {};
						if (!cfgObj.enabled || reqList.Initialized)
							return;
						iLog("Initialize", "Called");

						$.extend(_config, cfgObj);
						_wrapper = $('#reqListData');
						_lastReqList = lastXML;

						reqList.AllVRMs(_config.showAll);
						reqList.FilterVars(_config.filterVars);
						reqList.Filter(_config.filter, true);

						reqList.Initialized = true;
						reqList.Clear();
						reqList.Enable(true, true);
					} catch (err) {
						iLog("Initialize", err, log.Type.Error);
					}
				},
				Clear : function () {
					if (!reqList.Initialized)
						return;
					iLog("Clear", "Called");
					
					_reqID = 0;
					if (_reqTable.length)
						_reqTable.empty().remove();
					_reqTable = $('<table class="ReqList"><tr><th>ID</th><th>Name</th><th>Value</th></tr></table>');
					_wrapper.append(_reqTable);
				},
				Enable : function (value, initialRequest) {
					if (!reqList.Initialized)
						return;
					iLog("Enable", "Set to " + value);

					reqList.Enabled = value;
					
					utils.SetRadioOfName('rbEnabled', value);

					if (value && !_reqID)
						reqList.Load(_lastReqList, initialRequest);
				},		
				// Loads RL from xml - The XML of the entire response which may or may not contain a RL
				Load : function (xml, initialRequest) {
					try {
						if (!reqList.Initialized || !xml)
							return;
						iLog("Load", "Called");
						
						var sr = $(xml).find("stingray"),
							code = sr.find("errorcode").text();
						
						// Do not display RL of empty callbacks
						if (code == "0101")
							return;

						var vrmName = sr.find("vrmname").text(),
							rlXml = sr.find("reqlist");

						// To preserve performance skip for following conditions
						if (!rlXml || !reqList.Enabled || $.inArray(vrmName, reqList.ExcludeVRMs) > -1)
							return;
						
						if (initialRequest) {
							_lastReqList = xml;
							if (!_config.showAll)
								reqList.Clear();
							reqList.Add('VRM-PG', vrmName);
						} else {
							reqList.Add('VRM-PG', vrmName);
							if (!_config.showAll)
								return;
						};
						
						utils.ScrollDown();

						var s = $(rlXml).text();
						var arr = s.split(/\|{2}/g);
						for (var i = 0; i < arr.length; i++) {
							var m = arr[i],
								b = m.indexOf("="),
								name = m.substring(0, b),
								val = m.substring(b + 1);
							
							if (AddVarOfName(name))
								reqList.Add(name, val);
						};
						
						EnsureLimit();
						if (!_config.filterVars)
							filterBy(_config.filter);
					} catch (err) {
						iLog("Load", err, log.Type.Error, true);
					}
				},
				Add : function (name, value) {
					try {
						if (!reqList.Initialized)
							return null;
						
						var e = new Entry(name, value);
						var fe = FormatEntry(e);
						_reqTable.append(fe);
						return fe;
					} catch (err) {
						iLog("Add", err, log.Type.Error);
					}
				},
				AllVRMs : function (value) {
					if (value == undefined)
						_config.showAll = !_config.showAll;
					else
						_config.showAll = value;

					utils.SetRadioOfName('rbAll', value);
				},
				FilterVars : function (value) {
					if (value == undefined)
						_config.filterVars = !_config.filterVars;
					else
						_config.filterVars = value;

					utils.SetRadioOfName('rbFilter', value);
				},
				Filter : function (value, updateInput) {
					value = utils.Trim(value);
					value = utils.RemoveWhiteSpaces(value);
					_config.filter = value;
					
					filterBy(value);

					if (updateInput)
						$('#edFilter').val(value);
				},
				// Gets the HTML of the Table element
				GetList : function () {
					if (_lastReqList)
						return utils.GetXmlString(_lastReqList);
					else
						return "No ReqList";
				}
			}
		
		} catch (err) {
			iLog("Main", err, log.Type.Error);
		}
	};



	// WatchList viewer
	var watchList = new function () {
		try {

			/* PRIVATE PROPERTIES */
			var logClassName = "watchList.",
				_wrapper,
				_reqTable = $([]),
				_reqID = 0,
				_lastReqList,			// the last WL sent from stingray
				_config = {};
			
			function iLog(Place, Message, Type, Silent) {
				log.Add(logClassName + Place, Message, Type, Silent);
			}
			function Entry(name, value, newBP) {
				this.NewBP = newBP;
				this.Name = name;
				this.Value = value;
			}
			function FormatEntry(ent) {
				var le = $("<tr/>");
				if (ent.NewBP) {
					_reqID = 0;
					le.append("<td class='wpIndex'></td>");
					le.append("<td class='wpName'></td>");
					le.append("<td class='wpValue'>" + ent.Value + "</td>");
				} else {
					_reqID++;
					le.append("<td class='index'>" + _reqID + "</td>");
					le.append("<td class='name'>" + ent.Name + "</td>");
					le.append("<td class='value'><code class='ReqList'/></td>");
					le.find("code").text(ent.Value);
				};
				return le;
			}
			function Add(name, value, newBP) {
				try {
					var e = new Entry(name, value, newBP);
					_reqTable.append(FormatEntry(e));
				} catch (err) {
					iLog("Add", err, log.Type.Error);
				}
			}
			function filterBy(value) {
				iLog("filterBy", "Called: " + value);

				var rows = _reqTable.find("tr td.name").parent();
				if (!value) {
					rows.show();
				} else {
					var arr = value.split(" ");								
					for (var r = 0; r < rows.length; r++) {
						var tr = $(rows[r]);
						var name = tr.find("td.name").text();
						var found = false;

						$.each(arr, function (idx, itm) {
							var re = new RegExp(itm, "i");
							if (name.search(re) > -1) {
								found = true;
								return;
							};
						});
						if (found)
							tr.show()
						else
							tr.hide();
					}
				}
			}

			return {
			
				Enabled : false,
				Initialized : false,
				ExcludeVRMs : [],
				
				Initialize : function (cfgObj, lastXML) {
					try {
						cfgObj = cfgObj || {};
						if (!cfgObj.enabled || watchList.Initialized)
							return;
						iLog("Initialize", "Called");

						$.extend(_config, cfgObj);
						_wrapper = $('#watchListData');
						_lastReqList = lastXML;

						watchList.Filter(_config.filter, true);

						watchList.Initialized = true;
						watchList.Clear();
						watchList.Enable(true, true);
					} catch (err) {
						iLog("Initialize", err, log.Type.Error);
					}
				},
				Clear : function () {
					if (!watchList.Initialized)
						return;
					iLog("Clear", "Called");
					
					_reqID = 0;
					if (_reqTable.length)
						_reqTable.empty().remove();
					_reqTable = $('<table class="ReqList"><tr><th>ID</th><th>Name</th><th>Value</th></tr></table>');
					_wrapper.append(_reqTable);
				},
				Enable : function (value, initialRequest) {
					if (!watchList.Initialized)
						return;
					iLog("Enable", "Set to " + value);

					watchList.Enabled = value;
					
					utils.SetRadioOfName('rbEnabled', value);

					if (value && !_reqID)
						watchList.Load(_lastReqList, initialRequest);
				},		
				// Loads WL from xml - The XML of the entire response which may or may not contain a WL
				Load : function (xml, initialRequest) {
					try {
						if (!watchList.Initialized || !xml)
							return;
						iLog("Load", "Called");
						
						var sr = $(xml).find("stingray"),
							vrmName = sr.find("vrmname").text(),
							wlXml = sr.find("watchlist");

						// To preserve performance skip for following conditions
						if (!wlXml || !watchList.Enabled || $.inArray(vrmName, watchList.ExcludeVRMs) > -1)
							return false;
						
						var s = $(wlXml).text();
						if (!s)
							return false;
						var arr = $.parseJSON(s);
						if (!arr.length)
							return false;

						watchList.Clear();
						for (var i = 0; i < arr.length; i++) {
							var bp = arr[i];						
							Add("", bp.n, true);
							
							for (var y = 0; y < bp.v.length; y++) {
								var rl = bp.v[y];
								Add(rl.n, rl.v, false);
							};
						};
						
						if (!_config.filterVars)
							filterBy(_config.filter);
					} catch (err) {
						iLog("Load", err, log.Type.Error, true);
					}
				},
				FilterVars : function (value) {
					if (value == undefined)
						_config.filterVars = !_config.filterVars;
					else
						_config.filterVars = value;

					utils.SetRadioOfName('rbFilter', value);
				},
				Filter : function (value, updateInput) {
					value = utils.Trim(value);
					value = utils.RemoveWhiteSpaces(value);
					_config.filter = value;
					
					filterBy(value);

					if (updateInput)
						$('#edFilter').val(value);
				},
				// Gets the HTML of the Table element
				GetList : function () {
					if (_lastReqList)
						return utils.GetXmlString(_lastReqList);
					else
						return "No WatchList";
				}
			}
		
		} catch (err) {
			iLog("Main", err, log.Type.Error);
		}
	};



	// LogList viewer
	var logList = new function () {
		try {

			/* PRIVATE PROPERTIES */
			var logClassName = "logList.",
				_wrapper,
				_reqTable = $([]),
				_reqID = 0,
				_config = {};
			
			function iLog(Place, Message, Type, Silent) {
				log.Add(logClassName + Place, Message, Type, Silent);
			}
			function formatEntry(ent) {
				_reqID++;
				
				var le = $("<tr/>");
				le.append("<td class='index'>" + _reqID + "</td>");
				le.append("<td class='time'>" + ent.Time + "</td>");
				le.append("<td class='source filterBy'>" + ent.Source + "</td>");
				
				var td = $("<td class='" + ent.Type + " filterBy' />");
				td.append(ent.Message);
				le.append(td);

				return le;
			}
			function ensureLimit() {
				if (_reqID < 3000)
					return;

				if ((_reqID % 100) == 0)
					_reqTable.find("tr:gt(0):lt(101)").empty().remove();
			}
			function filterBy(value, rows) {
				if (!value) {
					rows.show();
				} else {
					var arr = value.split(" ");								
					for (var row = 0; row < rows.length; row++) {
						var tr = $(rows[row]);
						var cols = tr.find("td.filterBy");
						var found = false;
						var name = '';

						for (var col = 0; col < cols.length; col++) {
							var td = $(cols[col]);
							name += td.text() + ' ';
						}

						$.each(arr, function (idx, itm) {
							var re = new RegExp(itm, "i");
							if (name.search(re) > -1) {
								found = true;
								return;
							};
						});
						if (found)
							tr.show()
						else
							tr.hide();
					}
				}
			}

			return {
			
				Enabled : false,
				Initialized : false,
				
				Initialize : function (cfgObj) {
					try {
						cfgObj = cfgObj || {};
						if (!cfgObj.enabled || logList.Initialized)
							return;
						iLog("Initialize", "Called");

						$.extend(_config, cfgObj);
						_wrapper = $('#logListData');

						logList.Filter(_config.filter, true);
						logList.Initialized = true;
						logList.Clear();
						logList.Enable(false);
					} catch (err) {
						iLog("Initialize", err, log.Type.Error);
					}
				},
				Clear : function (clearMainTab) {
					if (!logList.Initialized)
						return;
					iLog("Clear", "Called");
					
					_reqID = 0;
					if (_reqTable.length)
						_reqTable.empty().remove();
					_reqTable = $('<table class="ReqList"><tr><th>ID</th><th>Time</th><th>Source</th><th>Message</th></tr></table>');
					_wrapper.append(_reqTable);
					
					if (clearMainTab)
						log.Clear();
				},
				Enable : function (value) {
					if (!logList.Initialized)
						return;
					iLog("Enable", "Set to " + value);

					logList.Enabled = value;
					
					utils.SetRadioOfName('rbEnabled', value);
				},		
				Load : function (logs) {
					try {
						iLog("Load", "Called");
						
						if (!logList.Initialized || !logs || !logs.length)
							return;

						for (var i = 0; i < logs.length; i++)
							logList.Add(logs[i]);
						
						if (_config.filter) {
							var rows = _reqTable.find("tr td.source").parent();
							filterBy(_config.filter, rows);
						}
					} catch (err) {
						iLog("Load", err, log.Type.Error, true);
					}
				},
				Add : function (ent) {
					if (!logList.Initialized) {
						// Log to console if available. LK: neither (console != undefined) nor (!console) work in IE!
						if (window.console != undefined && window.console.log != undefined)
							console.log(ent.Source, ent.Type, ' : ', ent.Message);
						
						return;
					}
					
					if (!logList.Enabled && ent.Type == log.Type.Info)
						return;

					ensureLimit();

					var row = formatEntry(ent);
					_reqTable.append(row);
					if (_config.filter && ent.Type != log.Type.Error)
						filterBy(_config.filter, row);
					
					utils.ScrollDown();

					return row;
				},
				FilterVars : function (value) {
					if (value == undefined)
						_config.filterVars = !_config.filterVars;
					else
						_config.filterVars = value;

					utils.SetRadioOfName('rbFilter', value);
				},
				Filter : function (value, updateInput) {
					value = utils.Trim(value);
					value = utils.RemoveWhiteSpaces(value);
					_config.filter = value;
					
					var rows = _reqTable.find("tr td.source").parent();
					filterBy(value, rows);

					if (updateInput)
						$('#edFilter').val(value);
				}
			}
		
		} catch (err) {
			iLog("Main", err, log.Type.Error);
		}
	};



	// Publish private core objects:
	tools.ReqList = reqList;
	tools.WatchList = watchList;
	tools.LogList = logList;

	// We are fully loaded!
}) (window, document, jQuery);
