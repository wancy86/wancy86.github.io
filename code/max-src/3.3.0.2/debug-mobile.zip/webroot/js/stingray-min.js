/** @license
  Copyright (c) 2008-2016, Maximum Processing Inc, All Rights Reserved.
  
  BEGIN of Core JS Objects
*/
if (typeof jQuery === 'undefined') {
	throw new Error("Bootstrap's JavaScript requires jQuery");
}

// Main enclosure
(function (window, document, $, undefined) {


	// Add new prototypes:
	Array.prototype.reset = function () {
		for (var i = 0; i < this.length; i++)
			this[i] = null;
	};
	Array.prototype.insert = function (index, item) {
  		this.splice(index, 0, item);
	};
	Array.prototype.toPipeString = function () {
		var str = "";
		for (var i = 0; i < this.length; i++) {
			str += this[i] + "|";
		}
		return str.substring(0, str.length - 1);
	};
	String.prototype.beginsWith = function (str) {
		var L = str.length;
		var begin = this.substring(0, L);
		return (begin == str);
	};
	String.prototype.endsWith = function (str) {
		var L = str.length;
		var end = this.substring(this.length - L);
		return (end == str);
	};
	String.prototype.removeLastChar = function () {
		return this.substring(0, this.length - 1);
	};
	String.prototype.removeFirstChar = function () {
		return this.substring(1);
	};
	String.prototype.insert = function (pos, str) {
		if (typeof pos == "object") {
			var ret = "";
			var lp = 0;
			for (var i = 0; i < pos.length; i++) {
				var p = pos[i];
				ret += this.substring(lp, p) + str;
				lp = p;
			}
			ret += this.substring(lp);
			return ret;
		}
		return this.substring(0, pos) + str + this.substring(pos);
	};
	// Removed in IE8!
	if(typeof String.prototype.trim !== 'function') {
		String.prototype.trim = function() {
			return this.replace(/^\s+|\s+$/g, '');
		};
	};
	
	$.fn.autocompleteList = function(cfg) {
		if (!cfg || !cfg.url)
			return dialog.Error('No URL provided!');

		cfg.data = cfg.data || {};
		cfg.data.id = cfg.data.id || comm.SessionID;
		cfg.varName = cfg.varName || 'term';

		this.each(function() {
			var cfgObj = {
				source: function( request, response ) {
					$.ajax({
						url: cfg.url + '?' + cfg.varName + '=' + request.term,
						data: cfg.data,
						success: function( data, status, jqXHR ) {
							if (utils.IsString(data)) {
								data = data || '';
								data = $.trim(data);
								
								var arr = [];
								if (data)
									arr = data.split(/[\n\r]/);
								if (cfg.done)
									arr = cfg.done(arr, status, jqXHR);
								
								response(arr);
							} else {
								var sr = $(data).find('stingray'),
									vrmName = sr.find('vrmname').text(),
									html = sr.find('html').text();
								status = sr.find('status').text();
								
								if (status != "success") {
									log.Add('$.autocompleteList', vrmName + " failed: " + html, log.Type.Error, true);
									var cb = cfg.fail || $.noop;
									if (!cb(html, status, jqXHR))
										dialog.Error(html);
								}
							}
						},
						error : function( jqXHR, status, error ) {
							log.Add('$.autocompleteList', status + ': ' + error.message, log.Type.Error, true);

							var cb = cfg.fail || $.noop;
							if (!cb(error.message, status, jqXHR))
								dialog.Error(error.message);
						}
					});
				},
			};
			$.extend(cfgObj, cfg);
			$(this).autocomplete(cfgObj);
		});
	};



	// Main/root core object for all JS!
	var mp = new function () {
		/* PRIVATE PROPERTIES */
		var config = {};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('mp.' + Place, Message, Type, Silent);
		}

		return {
			/* PUBLIC PROPERTIES */
			StingrayJsVersion : "3.3.0.2",

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);

				utils.Initialize(config.utils);
				notify.Initialize(config.notify);
				dialog.Initialize(config.dialog);
				log.Initialize(config.log);
				comm.Initialize(config.comm);
				script.Initialize(config.script);
				validator.Initialize(config.validator);
				tools.Initialize(config.tools);
				webSocket.Initialize(config.webSocket);
			},
			ShowVersion : function(msg) {
				msg = msg || 'Stingray core version : ';
				dialog.Alert(msg + MP.StingrayJsVersion);
			}
		}
	}



	// Core utilities
	var utils = new function () {
		/* PRIVATE PROPERTIES */
		var d = new Date(),
			curYr = d.getFullYear(),
			maxYr = curYr + 2,
			minYr = curYr - 100,
			rngYr = minYr + ':' + maxYr;

		var config = {
				popover: {
					selector: '.hasPopover',
					defaults: {
						placement: 'top',
						trigger: 'enter'
					}
				},
				tooltip: {
					selector: '.hasTooltip',
					defaults: {
						placement: 'top',
						trigger: 'hover focus'
					}
				},
				datepicker: {
					selector: '.isDatepicker',
					addClass: 'select_date',
					defaults: {
						changeYear: true,
						changeMonth: true,
						yearRange: rngYr
					}
				}
			};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('utils.' + Place, Message, Type, Silent);
		}
		function G() {
		  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
			},
			IsObject : function (o) {
				return (o && typeof o == "object");
			},
			IsFunction : function (o) {
				return (o && typeof o == "function");
			},
			IsNumber : function (o) {
				return (typeof o == "number");
			},
			IsString : function (o) {
				return (typeof o == "string");
			},
			Trim : function (str) {
				if (str)
					return str.trim();
				else
					return "";
			},
			RemoveWhiteSpaces : function (str) {
				if (str)
					return str.replace(/\s+/g, " ");
				else
					return "";
			},
			GetXmlString : function (xmlDocument) {
				if (xmlDocument.xml)
					return xmlDocument.xml;
				else
					return new XMLSerializer().serializeToString(xmlDocument);
			},
			SetRadioOfName : function(name, value) {
    			var s = 'input[name="' + name+ '"]';
    			var el = $(s);
    			el.prop('checked', false)
    			  .parent('label')
    			  .removeClass('active');
    			s = s + '[value="' + value + '"]';
    			el = $(s);
    			el.prop('checked', true)
    			  .parent('label')
    			  .addClass('active');
			},
			FirstVersionSameOrAboveSecond : function(version1, version2) {
				var v1 = version1.split('.'),
					v2 = version2.split('.'),
					lng = (v1.length < v2.length) ? v1.length : v2.length;

				for (i = 0; i < lng; i++) {
					var n1 = parseInt(v1[i]),
						n2 = parseInt(v2[i]);

					if (n1 > n2)
						return true;
					if (n1 < n2)
						return false;
				}
				return true;
			},
			MakeGUID : function() {
				return (G() + G() + "-" + G() + "-" + G() + "-" + G() + "-" + G() + G() + G()).toUpperCase();
			},
			// pads numbers with zero to the specified length [default padding = 2]
			PadNumber : function (num, padd) {
				padd = padd || 2;
				var s = "0000000000000000" + num;
				
				return s.substr(s.length - padd);
			},
			// returns the current time formatted "0h:0m:0s:00ms"
			GetFormattedTime : function () {
				var d = new Date();
				var t = utils.PadNumber(d.getHours()) + ":" + utils.PadNumber(d.getMinutes()) + ":" + utils.PadNumber(d.getSeconds()) + "." + utils.PadNumber(d.getMilliseconds(), 3);

				return t;
			},
			ScrollDown : function () {
				window.scrollTo(0, document.body.scrollHeight);
			},
			AddCore :function(target, cfgObj) {
				target = $(target);
				if (!target.length)
					return;

				var cfg = $.extend({}, cfgObj);

				// Rename selected attributes and classes
				if (cfg.renameAttr)
					$.each(cfg.renameAttr, function(oldName, newName) {
						var els = target.find('[' + oldName + ']');
						els.each(function(i, el) {
							el = $(el);
							var val = el.attr(oldName);
							el.removeAttr(oldName);
							el.attr(newName, val);
						});
					});

				if (cfg.renameClass)
					$.each(cfg.renameClass, function(oldName, newName) {
						var els = target.find('.' + oldName);
						els.each(function(i, el) {
							el = $(el);
							el.removeClass(oldName);
							el.addClass(newName);
						});
					});

				// Remove unwanted attributes and classes
				if (cfg.removeAttr)
					$.each(cfg.removeAttr, function(idx, oldName) {
						var els = target.find('[' + oldName + ']');
						els.each(function(i, el) {
							el = $(el);
							el.removeAttr(oldName);
						});
					});

				if (cfg.removeClass)
					$.each(cfg.removeClass, function(idx, oldName) {
						var els = target.find('.' + oldName);
						els.each(function(i, el) {
							el = $(el);
							el.removeClass(oldName);
						});
					});

				// add popovers
				el = target.find(config.popover.selector);
				if (el.length) {
					var c = $.extend({}, config.popover, cfg.popover);
					el.popover(c.defaults);
				}

				// add tooltips
				el = target.find(config.tooltip.selector);
				if (el.length) {
					var c = $.extend({}, config.tooltip, cfg.tooltip);
					el.tooltip(c.defaults);
				}

				// add datepickers
				el = target.find(config.datepicker.selector);
				if (el.length) {
					var c = $.extend({}, config.datepicker, cfg.datepicker);
					el.parent().addClass(c.addClass);
					el.datepicker(c.defaults);
				}


				el = target.find('[ref]');
				$.each(el, function(idx, el) {
					el = $(el);

					// Initialize our components (widgets)
					var attr = el.attr('init');
					if (attr) {
						iLog(el.attr('ref') + ".init", "Called", log.Type.Info);
						try {
							eval(attr);
						} catch (err) {
							iLog(el.attr('ref') + ".init", err, log.Type.Error, !tools.EditorEnabled());
						}
					}
				});

				validator.Add(target);
			},
			ParseURL : function (url) {
				url = url || window.location.href;

			    var parser = document.createElement('a'),
			        searchObject = {},
			        queries, split, i;
			    
			    // Let the browser do the work
			    parser.href = url;
			    
			    // Convert query string to object
			    queries = parser.search.replace(/^\?/, '').split('&');
			    for ( i = 0; i < queries.length; i++ ) {
			        split = queries[i].split('=');
			        searchObject[split[0].toLowerCase()] = split[1];
			    }
			    return {
			        protocol: parser.protocol,
			        host: parser.host,
			        hostname: parser.hostname,
			        port: parser.port,
			        pathname: parser.pathname,
			        search: parser.search,
			        searchObject: searchObject,
			        hash: parser.hash
			    };
			}
		}
	}



	// Core notifications
	var notify = new function () {
		/* PRIVATE PROPERTIES */
		var ntf = $();
		var config = {
				customNotify: $.notify,
				defaults: {}
			};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('notify.' + Place, Message, Type, Silent);
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
				ntf = config.customNotify;
				$.notifyDefaults(config.defaults);
			},
			CloseAll : function (location) {
				$.notifyClose(location);
			},
			Info : function (options, settings) {
				settings = settings || {};
				$.extend(settings, {type: 'info'});
				
				return ntf(options, settings);
			},
			Success : function (options, settings) {
				settings = settings || {};
				$.extend(settings, {type: 'success'});
				
				return ntf(options, settings);
			},
			Warning : function (options, settings) {
				settings = settings || {};
				$.extend(settings, {type: 'warning'});
				
				return ntf(options, settings);
			},
			Danger : function (options, settings) {
				settings = settings || {};
				$.extend(settings, {type: 'danger'});
				
				return ntf(options, settings);
			},
			Custom : function (options, settings) {
				return ntf(options, settings);
			}
		}
	}



	// Core dialogs
	var dialog = new function () {
		/* PRIVATE PROPERTIES */
		var dlg = $();
		var config = {
				customDialog: window.bootbox,
				defaults: {
					size: 'small',
					backdrop: true,
					closeButton: false
				}
			};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('dialog.' + Place, Message, Type, Silent);
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
				dlg = config.customDialog;
				dlg.setDefaults(config.defaults);
			},
			HideAll : function () {
				dlg.hideAll();
			},
			Alert : function () {
				return dlg.alert.apply(this, arguments);
			},
			Confirm : function () {
				return dlg.confirm.apply(this, arguments);
			},
			Prompt : function () {
				if (arguments.length < 3)
					return dlg.prompt.apply(this, arguments);
				else
					return dlg.prompt({
						title: arguments[0],
						callback: arguments[1],
						value: arguments[2]
					});
			},
			Error : function (message, callback) {
				var cfg = {
					title: 'ERROR',
					message: undefined,
					callback: callback
				};
				if (utils.IsObject(message))
					$.extend(cfg, message);
				else
					cfg.message = message;

				return dlg.alert(cfg);
			},
			Custom : function (message, callback) {
				var cfg = {
					title: undefined,
					message: undefined,
					size: 'large',
					closeButton: true,
					buttons: {
						ok: {
							label: "OK",
							className: "btn-primary",
							callback: callback
						}
					}
				};
				if (utils.IsObject(message))
					$.extend(cfg, message);
				else
					cfg.message = message;

				return dlg.dialog(cfg);
			}
		}
	}



	// Core logging
	var log = new function () {
		/* PRIVATE PROPERTIES */
		var config = {},
			_logList,
			_entries = [],
			_lastSentErrTime = new Date();
		
		/* PRIVATE METHODS */
		function Entry(src, msg, type) {
			this.Source = src;
			this.Message = jsErrorToStr(msg);
			this.Time = utils.GetFormattedTime();
			this.Type = type || log.Type.Info;
		}
		function jsErrorToStr(Message) {
			if (!utils.IsObject(Message))
				return Message;
				
			var msg;
			if (Message.message)
				msg = Message.message;
			else
				msg = Message.Message.description;
			
			msg += " [";
			if (Message.fileName)
				msg += Message.fileName + ", ";
			if (Message.lineNumber)
				msg += Message.lineNumber + ", ";
			if (Message.EntryID)
				msg += Message.EntryID;
			msg += ']';
			
			return msg;
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
			},
			Debug : function (Message) {
				log.Add('DEBUG', Message, log.Type.Debug);
			},
			Clear : function () {
				$('#dtbLog').removeClass('error warning debug search');
				_entries = [];
			},
			Set : function (logList) {
				_logList = logList;
			},
			CachedLogs : function () {
				var e = _entries;
				_entries = [];

				return e;
			},
			Add : function (source, message, type, silentError) {
				var ent = new Entry(source, message, type);
				if (_logList)
					_logList.Add(ent);

				// Cache important non info log entries for when log tab is open
				if (!_logList && ent.Type != log.Type.Info)
					_entries.push(ent);

				// Update toolbar button
				if (ent.Type != log.Type.Info)
					$('#dtbLog').toggleClass(ent.Type, true);

				// Do more for errors only!
				if (ent.Type != log.Type.Error)
					return;

				// Log errors to console if available
				if (window.console && window.console.log)
					console.log(ent.Type + ': ' + ent.Source + ': ' + ent.Message);
				
				// Send live errors to the server. Limit 1 post per 2 seconds!
				if (!tools.EditorEnabled()) {
					var now = new Date(),
						ms =  new Date(now - _lastSentErrTime);
					if (ms > 2000 && $.inArray(ent.Source, ['comm.Post', 'comm.Get']) == -1) {
						_lastSentErrTime = now;
						var rl,
							xml = tools.GetLastXML();
						if (xml) {
							var sr = $(xml).find("stingray");
							var vn = sr.find("vrmname").text();
							var rlx = sr.find("reqlist");
							if (rlx)
								rl = rlx.text();
						}

						comm.Post({
							url: 'logging.max',
							serializeElement : null,
							targetElement : null,
							eventElement : null,
							data: {
								action: 'log',
								source: ent.Source + ' (' + MP.StingrayJsVersion + ')',
								vrmName: vn,
								message: ent.Message,
								reqList: rl
							}
						});
					}
				}

				if (!silentError)
					dialog.Error(ent.Message);
			},
			Type : new function () {
				this.Error = "error";
				this.Info = "info";
				this.Warning = "warning";
				this.Debug = "debug";
				this.Search = "search";
			}
		}
	}



	// Core communication
	var comm = new function () {
		/* PRIVATE PROPERTIES */
		var lastDebug = "",
			spinner = $(),
			EnableSessionTimer = true, // Defaultly enabled for live, disabled for developer modes
			lastTimeoutReset, // Last time a page is loaded
			timeoutDlg = $(),
			timeoutID,
			loggedOut = 'LOGGED OUT';

		var config = {
				sessionTimeOut: 3600, // Default number of seconds until a session expires
				sessionWarningTime: 120, // Default seconds before expiration to display the expiration message
			};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('comm.' + Place, Message, Type, Silent);
		}
		function Request() {
			this.async = true;
			this.cache = false;
			this.initialRequest = false;
			this.method = "POST";
			this.data = null;
			this.id = "";
			this.host = "../../";
			this.template = "";
			this.timeout = 180000;
			this.dataType = "xml";
			this.url = null;
			this.requestType = "";
			this.done = $.noop;
			this.fail = $.noop;
		}
		function getValueFromURL(url, name) {
			return decodeURIComponent((new RegExp('[?|&]' + name + '=([^&;]+?)(&|#|;|$)', 'i').exec(url) || [,""])[1].replace(/\+/g, '%20')) || null
		}
		function initAfterLogin(newSess) {
			var oldSess = comm.SessionID;
			if (newSess) {
				comm.SessionID = newSess;
				if (!oldSess) {
					// We have a brand new valid session!
					
				}
			}
		}
		function updateSessionFromURL(url) {
			if (!url)
				return;
			
			initAfterLogin(getValueFromURL(url, 'id'));
		}
		function updateSessionFromXML(xml) {
			if (!xml)
				return;
			
			var sr = $(xml).find("stingray");
			initAfterLogin(sr.find("id").text());

			var dbg = sr.find('debug').text();
			if (dbg && dbg != lastDebug) {
				lastDebug = dbg;
				var cfg = $.parseJSON(dbg);
				tools.UpdateConfig(cfg);
			};

			var vrm = sr.find('vrmname').text().toLowerCase();
			if (!comm.InitialRequest || !vrm || $.inArray(vrm, ['na', 'ajax', 'titletop', 'icontray', 'mainfooter', 'topmenu', 'admintabs', 'tablewalker']) > -1)
				return;

			tools.ShowVrmName(vrm);
		}
		function executeCallback(xml) {
			try {
				iLog("executeCallback", "Called");
				
				var cb = $(xml).find('stingray>callback').text();
				if (cb == 1) {
					comm.Post($('<div VRMName="callback"/>'), {isCallback: true});
					iLog("executeCallback", "Requested");
				}
			} catch (err) {
				iLog("executeCallback", err, log.Type.Error);
			}
		}
		function processRequest(objRequest) {
			try {
				iLog("processRequest", "Called");
				
				comm.InitialRequest = objRequest.initialRequest;
				
				// Make all necessary URL adjustments
				var url = objRequest.url;
				if (!url)
					url = objRequest.host + objRequest.template;
				
				var d = new Date(),
					t = d.getTime().toString(),
					s = "t=" + t;
				url += (url.indexOf("?") == -1) ? "?" + s : "&" + s;
				objRequest.url = url;

				resetTimeout();
				
				// Add client/server protocol API
				var api = 'id=' + objRequest.id;
				if (comm.UserLanguage)
					api = api + '&csul=' + comm.UserLanguage;
				
				var	data = objRequest.data || '';
				if (data && !data.beginsWith("&"))
					data = "&" + data;
				
				objRequest.data = api + data;
				
				var req = $.ajax({
					url : objRequest.url,
					data : objRequest.data,
					cache : objRequest.cache,
					timeout : objRequest.timeout,
					processData : true,
					dataType : objRequest.dataType,
					type : objRequest.method,
					async : objRequest.async,
					success : function (data) {
						tools.Update(data);

						objRequest.onSuccess(data);
					},
					error : function (XMLHttpRequest, textStatus, errorThrown) {
						try {
							var s = "";
							try {
								s = Utilities.ToString(XMLHttpRequest);
							} catch (err) {
								s = "XMLHttpRequest failed to serialize: " + err.message;
								iLog("ProcessRequest", s, log.Type.Error, true);
							}
							
							var msg = "Error: " + errorThrown + ", Status: " + textStatus;
							tools.Update(s);
							objRequest.onError(msg, s);
						} catch (err) {
							iLog("ProcessRequest", err, log.Type.Error);
						}
					},
					complete : function () {
					}
				});
			} catch (err) {
				iLog("ProcessRequest", err, log.Type.Error);
			}
		}
		function makePostData(cfgObj, data) {
			var rd = data || '',
				sd;

			// Firstly add custom data if present
			if (!cfgObj.data || utils.IsString(cfgObj.data))
				sd = cfgObj.data;
			else
				sd = $.param(cfgObj.data);
			rd += (sd) ? '&' + sd : '';

			// Secondly try to add submit data if available
			try {
				var el = $(cfgObj.eventElement),
					subAct = el.attr("name"),
					subVal = el.val();

				rd += (subAct) ? '&SubmitAct=' + subAct : '';
				rd += (subVal) ? '&SubmitVal=' + subVal : '';
			} catch (err) {
				iLog("makePostData", "Wrong eventElement!", log.Type.Error, true);
			}
			
			// Lastly serialize form element
			sd = comm.Serialize(cfgObj.serializeElement);
			rd += (sd) ? '&' + sd : '';
			
			return rd;
		}
		function makeConfigObject(cfgObj) {
			var cfg = cfgObj || {};
			
			// URL string as the only parameter
			if (utils.IsString(cfg))
				cfg = {url: cfg};

			// jQuery as the only parameter
			if (cfg instanceof $)
				cfg = {eventElement: cfg};

			// this/element as the only parameter
			if (cfg.tagName && cfg.type)
				cfg = {eventElement: cfg};
			
			// Do not set if set to null!
			if (cfg.eventElement === undefined && window.event) {
				var e = window.event.target || window.event.srcElement,
					b = e instanceof XMLHttpRequest;
				if (e && !b)
					cfg.eventElement = e;
			}

			return cfg;
		}
		function attachDefaultSubmit() {
			var bc = $('#bootstrapContent');
			bc.unbind("keydown.bootstrapContent").bind("keydown.bootstrapContent", function (event) {
				if (event.keyCode == 13 && !$(event.target).is(':button')) {
					var el = $(event.target);

					// get parent with default attr or the whole page
					var def = el.closest('[default]'),
						div = def.length ? def : bc;
					
					// find default button by its value/selector or as the only child
					var btn,
						id = div.attr('default');
					if (id)
						btn = bc.find(id);
					else
						btn = div.find('[default="true"]');
					
					if (btn.length != 1) {
						iLog("defaultSubmit", "There are " + btn.length + " default submit buttons on the page! Submit skipped.", log.Type.Warning);
						return;
					}

					var e = new $.Event("click");
					btn.trigger(e);
				}
			});
		}
		function updatePage(target, html, vrmName) {
			var t = $(target);
			t.removeClass('modal-open');
			validator.Remove(t);

			if (html)
				t.html(html);
			t.attr("vrmName", vrmName);

			script.Load(t);
			utils.AddCore(t);

			return t;
		}
		function validationErrors(config) {
			var el = $(config.eventElement),
				val = config.validate || el.attr("validate") == "true";
			if (!val)
				return;

			var errors = validator.Validate(config.serializeElement);
			if (errors.length) {
				// Trigger it last in case they show dialogs with overlay
				var cs = window.CustomScript || {},
					gs = window.GlobalScript || {},
					cb = cs.OnValidationErrors || gs.OnValidationErrors || $.noop,
					noValidationDialog = cb(errors);
				
				if (noValidationDialog || config.noValidationDialog)
					return true;

				dialog.Error({title: 'Please correct the following', message: errors.join('<br>')});
				return true;
			}
		}
		function resetTimeout() {
			iLog("resetTimeout", "Called");
			
			lastTimeoutReset = new Date();
			timeoutDlg = $();
		}
		function initTimeout() {
			iLog("initTimeout", "Called");
			
			if (!timeoutID)
				timeoutID = setInterval(checkTimeout, 1000);
		}
		function getExpiringTime() {
			var s = lastTimeoutReset.getTime(),
				n = new Date().getTime(),
				t = (n - s) / 1000,
				tr = config.sessionTimeOut - Math.round(t),
				msg = '';

			if (tr > 59) {
				var m = Math.floor(tr / 60);
				tr = tr % 60;
				msg = m + ' minute' + (m > 1 ? 's' : '') + ' and ';
			}
			msg += tr + ' second' + (tr > 1 ? 's' : '');
			
			return msg;
		}
		function checkTimeout() {
			if (!lastTimeoutReset || !comm.SessionID || !EnableSessionTimer)
				return;
			
			var s = lastTimeoutReset.getTime(),
				n = new Date().getTime(),
				t = (n - s) / 1000,
				tr = config.sessionTimeOut - Math.round(t);

			if (timeoutDlg.length) {
				timeoutDlg.find("#time").text(getExpiringTime());
				if (tr <= 0) {
					resetTimeout();
					dialog.HideAll();
					comm.LogOut();
				}
				return;
			}

			if (t > (config.sessionTimeOut - config.sessionWarningTime)) {
				var initTime = getExpiringTime();

				timeoutDlg = dialog.Custom({
					title: 'Expiring Session',
					message: 'Due to system inactivity your session is about to expire. You will be automatically logged off in <b id="time">' + initTime + '</b>.',
					closeButton: false,
					size: 'small',
					buttons: {
						cont: {
							label: "Continue Using System",
							className: "btn-default",
							callback: function() {
								resetTimeout();
							}
						}
					}
				});
			}
		}
		function stripNonNumericalCharacters(text) {
			return text.replace(/[^-\d\.]/g, '');
		}

		return {
			/* PUBLIC PROPERTIES */
			SessionID : '',
			InitialRequest : false,
			UserLanguage : 'en',

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
				
				spinner = $('#spinnerOverlay');
				if (!spinner.length)
					spinner = $('<div id="spinnerOverlay" class="defaultSpinner"></div>').appendTo('body');
				spinner.hide();
				attachDefaultSubmit();
				initTimeout();
			},
			InProgress : function () {
				return spinner && spinner.is(":visible");
			},
			ShowProgress : function (blurInput) {
				blurInput = $(blurInput);
				if (blurInput.length)
					blurInput.blur();

				return spinner.show();
			},
			HideProgress : function () {
				return spinner.hide();
			},
			Get : function (cfgObj) {
				try {
					iLog("Get", "Called");
					
					var cfg = makeConfigObject(cfgObj);
					if (!cfg.url)
						return dialog.Error('No URL provided!');

					updateSessionFromURL(cfg.url);

					if (validationErrors(cfg))
						return;
					
					if (!cfg.noProgress)
						comm.ShowProgress($(cfg.eventElement));
					
					var request = new Request();
					$.extend(request, cfg);
					request.requestType = "Get";
					request.id = comm.SessionID;
					request.initialRequest = true;
					request.data = makePostData(cfg, (request.id) ? '&preprocess=true' : '');
					request.template = cfg.url;

					request.onSuccess = function (xml) {
						comm.HideProgress();
						updateSessionFromXML(xml);
						
						var sr = $(xml).find('stingray');
						var status = sr.find('status').text();
						var vrmName = sr.find('vrmname').text();
						var html = sr.find('html').text();
						
						// Skip page update if target is set to null!
						var target = cfg.targetElement;
						if (target === undefined)
							target = '#' + sr.find('target').text();
						
						if (status == "success") {
							iLog("Get", vrmName + " succeeded", log.Type.Info);

							if (target && target != '#')
								updatePage(target, html, vrmName);

							request.done(html, xml, vrmName);
						} else {
							iLog("Get", vrmName + " failed: " + html, log.Type.Error, true);
							if (!request.fail(html, xml, vrmName));
								dialog.Error(html);
						}
						executeCallback(xml);
					};
					request.onError = function (msg, xml) {
						iLog("Get", "Failed! " + msg, log.Type.Error, true);
						comm.HideProgress();
						if (!request.fail(msg, xml));
							dialog.Error(msg);
					};

					processRequest(request);

					return request;
				} catch (err) {
					iLog("Get", err, log.Type.Error);
					comm.HideProgress();
					if (request)
						request.fail(err.message);
				}
			},
			Post : function (cfgObj) {
				try {
					iLog("Post", "Called");

					var cfg = makeConfigObject(cfgObj);
					if (validationErrors(cfg))
						return;

					if (!cfg.noProgress)
						comm.ShowProgress($(cfg.eventElement));

					var request = new Request();
					$.extend(request, cfg);
					request.requestType = "Post";
					request.id = comm.SessionID;
					request.initialRequest = !cfg.isCallback;
					if (cfg.url)
						// CustomRequest
						request.template = cfg.url;
					else {
						// SerialRequest
						var se;
						if (cfg.serializeElement === undefined)
							se = $('#bootstrapContent');
						else
							se = $(cfg.serializeElement);
						
						var vn = se.attr("vrmName");
						if (!vn)
							vn = $('#bootstrapContent').attr("vrmName");
						cfg.serializeElement = se;
						if (!vn)
							return dialog.Error('Missing vrmName attribute!');
						request.template = vn + ".max";
					}
					request.data = makePostData(cfg);
					
					request.onSuccess = function (xml) {
						try {
							comm.HideProgress();
							updateSessionFromXML(xml);

							var sr = $(xml).find('stingray');
							var status = sr.find('status').text();
							var vrmName = sr.find('vrmname').text();
							var html = sr.find('html').text();

							// Skip page update if target is set to null!
							var target = cfg.targetElement;
							if (target === undefined)
								target = '#' + sr.find('target').text();
							
							if (status == "success") {
								iLog("Post", vrmName + " succeeded", log.Type.Info);
								
								if (target && target != '#')
									updatePage(target, html, vrmName);

								request.done(html, xml, vrmName);
							} else {
								var code = sr.find('errorcode').text();
								if (code != "0101") {
									code = code || html;
									iLog("Post", vrmName + " failed: " + code, log.Type.Error, true);
									if (!request.fail(html, xml, vrmName));
										dialog.Error(html);
								}
							}
							executeCallback(xml);
						} catch (err) {
							iLog("Post", err, log.Type.Error, true);
							if (!request.fail(err.message, xml, vrmName))
								dialog.Error(err.message);
						}
					};
					request.onError = function (msg, xml) {
						iLog("Post", "Failed! " + msg, log.Type.Error, true);
						comm.HideProgress();
						if (!request.fail(msg, xml))
							dialog.Error(msg);
					};

					processRequest(request);

					return request;
				} catch (err) {
					iLog("Post", err, log.Type.Error);
					comm.HideProgress();
					if (request)
						request.fail(err.message);
				}
			},
			Serialize : function (HTML) {
				try {
					var els = $(HTML).find(':input').get();
					if (!els.length)
						return '';

					var toReturn = [],
						cs = window.CustomScript || {},
						gs = window.GlobalScript || {},
						onSerVal = cs.OnSerializedValue || gs.OnSerializedValue;

					$.each(els, function () {
						if (this.name && !this.disabled && (this.checked || /select|textarea/i.test(this.nodeName) || /text|hidden|password/i.test(this.type))) {
							var e = $(this),
								n = encodeURIComponent(this.name),
								val = e.val(),
								vdt = e.attr('validator');
							
							// Some validators must be adjusted for submit
							if (vdt)
								vdt = vdt.substring(0, vdt.indexOf('('));
							switch (vdt) {
								case 'currency':
									val = stripNonNumericalCharacters(val);
									break;
							};

							// Execute custom or global OnSerializedValue events
							if (onSerVal)
								val = onSerVal(val, n, e);

							toReturn.push(n + "=" + encodeURIComponent(val));
						}
					});
					var ret = toReturn.join("&").replace(/%20/g, "+");
					
					return ret;
				} catch (err) {
					iLog("Serialize", err, log.Type.Error);
				}
			},
			OpenWindow : function (url, tabName, config) {
				iLog("OpenWindow", url);
				
				resetTimeout();
				/*
				var ul = comm.UserLanguage;
				if (ul)
					ul = '&csul=' + ul;
				var loc = "../../window.htm?id=" + comm.SessionID + ul + "&template=" + url;
				*/
				
				return window.open(url, tabName, config);
			},
			SessionOK : function () {
				return comm.SessionID && comm.SessionID != loggedOut;
			},
			LogOut : function (message) {
				iLog("LogOut", "Called");

				function logOut() {
					comm.Get('logout.max');
					comm.SessionID = loggedOut;
				}

				if (!message)
					logOut();
				else {
					dialog.Confirm(message, function(answer) {
				    	if (answer)
				        	logOut();
					});
				}
			}
		}
	}

	

	// Core scripting
	var script = new function () {
		/* PRIVATE PROPERTIES */
		var config = {},
			jsDiv;
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('script.' + Place, Message, Type, Silent);
		}
		function Script(name, params, body) {
			this.Name = $.trim(name);
			this.Params = params;
			this.Body = body;
		}
		function getFunctions(str) {
			try {
				iLog("getFunctions", "Called");
				
				str = "\n" + str.substring(str.indexOf("function "), str.length);
				var arr = [];
				
				var fns = str.split(/[\n\r]function /);
				if (!fns)
					return arr;
				
				for (var i = 0; i < fns.length; i++) {
					var fn = fns[i];
						
					var _name = fn.substring(0, fn.indexOf("{"));
					var params = _name.match(/\([^\)]+\)/g);
					if (params == null || params.length == 0)
						params = "";
					else
						params = params[0];
					params = params.replace("(", "").replace(")", "");
					if (_name.indexOf("(") > -1)
						_name = _name.substring(0, _name.indexOf("("));
					if (!_name)
						continue;
					var body = fn.substring(fn.indexOf("{") + 1);
					body = body.substring(0, body.lastIndexOf("}"));
					var funct = new Script(_name, params, body);
					arr.push(funct);
				}
				return arr;
			} catch (err) {
				iLog("getFunctions", err, log.Type.Error);
			}
		}
		function parseScript(strScript) {
			try {
				iLog("parseScript", "Called");
				
				var s = $.trim(strScript);
				if (s.beginsWith('('))
					return parseNewCustomScripts(s, false);
				else
					return parseOldCustomScripts(s, true);
			} catch (err) {
				iLog("parseScript", err, log.Type.Error, true);
				return err.message;
			}
		}
		function parseNewCustomScripts(code, clearScripts) {
			try {
				eval(code);
			} catch (err) {
				iLog("parseNewCustomScripts", err.message, log.Type.Error, true);
				return err.message;
			}
		}
		function parseOldCustomScripts(code, clearScripts) {
			var fns = getFunctions(code);
			if (!fns.length)
				return;

			if (clearScripts)
				script.Clear();
			
			var e = '',
				fn = null;
			for (var i = 0; i < fns.length; i++) {
				try {
					fn = fns[i];
					window.CustomScript[fn.Name] = new Function(fn.Params, fn.Body);
				} catch (err) {
					if (fn)
						e = e + fn.Name + " : " + err.message + ", ";
					else
						e = e + err.message + ", ";
				}
			};
			if (e) {
				iLog("parseOldCustomScripts", e, log.Type.Error, true);
				return e;
			};
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
			},
			Clear : function () {
				window.CustomScript = null;
				window.CustomScript = {};
			},
			Load : function (target) {
				iLog("Load", "Called");

				var jsDiv = $(target).find('[ref=js]');
				jsDiv.each(function(i, el) {
					var div = $(el),
						code = div.find('pre').text();
					parseScript(code);
					div.remove();
				});
				script.Execute(target);
			},
			Execute : function (target) {
				try {
					iLog("Execute", "Called");
					
					// Execute JS's Global and VRM's Custom OnLoad events
					if (window.GlobalScript && window.GlobalScript.OnLoad) {
						iLog("GlobalScript.OnLoad", "Called", log.Type.Info);
						try {
							window.GlobalScript.OnLoad(target);
						} catch (err) {
							iLog("GlobalScript.OnLoad", err, log.Type.Error, !tools.EditorEnabled());
						};
					};
					
					if (window.CustomScript && window.CustomScript.OnLoad) {
						iLog("CustomScript.OnLoad", "Called", log.Type.Info);
						try {
							window.CustomScript.OnLoad(target);
						} catch (err) {
							iLog("CustomScript.OnLoad", err, log.Type.Error, !tools.EditorEnabled());
						};
						window.CustomScript.OnLoad = null;
					};
				} catch (err) {
					iLog("MakeAllCompsDefault", err, log.Type.Error);
				}
			}
		}
	}



	// Core validation
	var validator = new function () {
		/* PRIVATE PROPERTIES */
		var config = {
				framework: 'bootstrap',
				trigger: 'blur',
				icon: {
					valid: '',
					invalid: '',
					validating: ''
				},
				requiredClass: 'req-field',
				currency: {
					aSign: '$'
				}
	        };
		var inProgress = false;
		var dlStates = {
			AL: {
				rule: "^\\d{1,7}$",
				desc: "1-7 Numeric"
			},
			AK: {
				rule: "^\\d{1,7}$",
				desc: "1-7 Numbers"
			},
			AZ: {
				rule: "(^[A-Z]{1}\\d{1,8}$)|(^[A-Z]{2}\\d{2,5}$)|(^\\d{9}$)",
				desc: "1 Alpha + 1-8 Numeric, 2 Alpha + 2-5 Numeric, 9 Numeric"
			},
			AR: {
				rule: "^\\d{4,9}$",
				desc: "4-9 Numeric"
			},
			CA: {
				rule: "^[A-Z]{1}\\d{7}$",
				desc: "1 Alpha + 7 Numeric"
			},
			CO: {
				rule: "(^\\d{9}$)|(^[A-Z]{1}\\d{3,6}$)|(^[A-Z]{2}\\d{2,5}$)",
				desc: "9 Numeric, 1 Alpha + 3-6 Numeric, 2 Alpha + 2-5 Numeric"
			},
			CT: {
				rule: "^\\d{9}$",
				desc: "9 Numeric"
			},
			DE: {
				rule: "^\\d{1,7}$",
				desc: "1-7 Numeric"
			},
			DC: {
				rule: "(^\\d{7}$)|(^\\d{9}$)",
				desc: "7 Numeric, 9 Numeric"
			},
			FL: {
				rule: "^[A-Z]{1}\\d{12}$",
				desc: "1 Alpha + 12 Numeric"
			},
			GA: {
				rule: "^\\d{7,9}$",
				desc: "7-9 Numeric"
			},
			GU: {
				rule: "^[A-Z]{1}\\d{14}$",
				desc: "1 Alpha + 14 Numeric"
			},
			HI: {
				rule: "(^[A-Z]{1}\\d{8}$)|(^\\d{9}$)",
				desc: "1 Alpha + 8 Numeric, 9 Numeric"
			},
			ID: {
				rule: "(^[A-Z]{2}\\d{6}[A-Z]{1}$)|(^\\d{9}$)",
				desc: "2 Alpha + 6 Numeric + 1 Alpha, 9 Numeric"
			},
			IL: {
				rule: "^[A-Z]{1}\\d{11,12}$",
				desc: "1 Alpha + 11-12 Numeric"
			},
			IN: {
				rule: "(^[A-Z]{1}\\d{9}$)|(^\\d{9,10}$)",
				desc: "1 Alpha + 9 Numeric, 9-10 Numeric"
			},
			IA: {
				rule: "^(\\d{9}|(\\d{3}[A-Z]{2}\\d{4}))$",
				desc: "9 Numeric, 3 Numeric + 2 Alpha + 4 Numeric"
			},
			KS: {
				rule: "(^([A-Z]{1}\\d{1}){2}[A-Z]{1}$)|(^[A-Z]{1}\\d{8}$)|(^\\d{9}$)",
				desc: "1 Alpha + 1 Numeric + 1 Alpha + 1 Numeric + 1 Alpha, 1 Alpha + 8 Numeric, 9 Numeric"
			},
			KY: {
				rule: "(^[A-Z]{1}\\d{8,9}$)|(^\\d{9}$)",
				desc: "1 Alpha + 8-9 Numeric, 9 Numeric"
			},
			LA: {
				rule: "^\\d{1,9}$",
				desc: "1-9 Numeric"
			},
			ME: {
				rule: "(^\\d{7,8}$)|(^\\d{7}[A-Z]{1}$)",
				desc: "7-8 Numeric, 7 Numeric + 1 Alpha"
			},
			MD: {
				rule: "^[A-Z]{1}\\d{12}$",
				desc: "1Alpha+12Numeric"
			},
			MA: {
				rule: "(^[A-Z]{1}\\d{8}$)|(^\\d{9}$)",
				desc: "1 Alpha + 8 Numeric, 9 Numeric"
			},
			MI: {
				rule: "(^[A-Z]{1}\\d{10}$)|(^[A-Z]{1}\\d{12}$)",
				desc: "1 Alpha + 10 Numeric, 1 Alpha + 12 Numeric"
			},
			MN: {
				rule: "^[A-Z]{1}\\d{12}$",
				desc: "1 Alpha + 12 Numeric"
			},
			MS: {
				rule: "^\\d{9}$",
				desc: "9 Numeric"
			},
			MO: {
				rule: "(^[A-Z]{1}\\d{5,9}$)|(^[A-Z]{1}\\d{6}[R]{1}$)|(^\\d{8}[A-Z]{2}$)|(^\\d{9}[A-Z]{1}$)|(^\\d{9}$)",
				desc: "1 Alpha + 5-9 Numeric, 1 Alpha + 6 Numeric + 'R', 8 Numeric + 2 Alpha, 9 Numeric + 1 Alpha, 9 Numeric"
			},
			MT: {
				rule: "(^[A-Z]{1}\\d{8}$)|(^\\d{13}$)|(^\\d{9}$)|(^\\d{14}$)",
				desc: "1 Alpha + 8 Numeric, 13 Numeric, 9 Numeric, 14 Numeric"
			},
			NE: {
				rule: "^\\d{1,7}$",
				desc: "1-7 Numeric"
			},
			NV: {
				rule: "(^\\d{9,10}$)|(^\\d{12}$)|(^[X]{1}\\d{8}$)",
				desc: "9 Numeric, 10 Numeric, 12 Numeric, 'X' + 8 Numeric"
			},
			NH: {
				rule: "^\\d{2}[A-Z]{3}\\d{5}$",
				desc: "2 Numeric + 3 Alpha + 5 Numeric"
			},
			NJ: {
				rule: "^[A-Z]{1}\\d{14}$",
				desc: "1 Alpha + 14 Numeric"
			},
			NM: {
				rule: "^\\d{8,9}$",
				desc: "8 Numeric, 9 Numeric"
			},
			NY: {
				rule: "(^[A-Z]{1}\\d{7}$)|(^[A-Z]{1}\\d{18}$)|(^\\d{8}$)|(^\\d{9}$)|(^\\d{16}$)|(^[A-Z]{8}$)",
				desc: "1 Alpha + 7 Numeric, 1 Alpha + 18 Numeric, 8 Numeric, 9 Numeric, 16 Numeric, 8 Alpha"
			},
			NC: {
				rule: "^\\d{1,12}$",
				desc: "1-12 Numeric"
			},
			ND: {
				rule: "(^[A-Z]{3}\\d{6}$)|(^\\d{9}$)",
				desc: "3 Alpha + 6 Numeric, 9 Numeric"
			},
			OH: {
				rule: "(^[A-Z]{1}\\d{4,8}$)|(^[A-Z]{2}\\d{3,7}$)|(^\\d{8}$)",
				desc: "1 Alpha + 4-8 Numeric, 2 Alpha + 3-7 Numeric, 8 Numeric"
			},
			OK: {
				rule: "(^[A-Z]{1}\\d{9}$)|(^\\d{9}$)",
				desc: "1 Alpha + 9 Numeric, 9 Numeric"
			},
			OR: {
				rule: "^\\d{1,9}$",
				desc: "1-9 Numeric"
			},
			PA: {
				rule: "^\\d{8}$",
				desc: "8 Numeric"
			},
			PR: {
				rule: "(^\\d{9}$)|(^\\d{5,7}$)",
				desc: "5-7 Numeric, 9 Numeric"
			},
			RI: {
				rule: "^(\\d{7}$)|(^[A-Z]{1}\\d{6}$)",
				desc: "7 Numeric, 1 Alpha + 6 Numeric"
			},
			SC: {
				rule: "^\\d{5,11}$",
				desc: "5-11 Numeric"
			},
			SD: {
				rule: "(^\\d{6,10}$)|(^\\d{12}$)",
				desc: "6-10 Numeric, 12 Numeric"
			},
			TN: {
				rule: "^\\d{7,9}$",
				desc: "7-9 Numeric"
			},
			TX: {
				rule: "^\\d{7,8}$",
				desc: "7-8 Numeric"
			},
			UT: {
				rule: "^\\d{4,10}$",
				desc: "4-10 Numeric"
			},
			VT: {
				rule: "(^\\d{8}$)|(^\\d{7}[A]$)",
				desc: "8 Numeric, 7 Numeric + 'A'"
			},
			VA: {
				rule: "(^[A-Z]{1}\\d{8,11}$)|(^\\d{9}$)",
				desc: "1 Alpha + 8 Numeric, 1 Alpha + 9 Numeric, 1 Alpha + 10 Numeric, 1 Alpha + 11 Numeric, 9 Numeric"
			},
			WA: {
				rule: "^(?=.{12}$)[A-Z]{1,7}[A-Z0-9\\*]{4,11}$",
				desc: "1-7 Alpha + any combination of Alpha, Numeric, and * for a total of 12 characters"
			},
			WV: {
				rule: "(^\\d{7}$)|(^[A-Z]{1,2}\\d{5,6}$)",
				desc: "7 Numeric, 1-2 Alpha + 5-6 Numeric"
			},
			WI: {
				rule: "^[A-Z]{1}\\d{13}$",
				desc: "1 Alpha + 13 Numeric"
			},
			WY: {
				rule: "^\\d{9,10}$",
				desc: "9-10 Numeric"
			},
			default: {
				rule: "^[0-9A-Z]{4,9}$",
				desc: "4-9 Alpha Numeric"
			}
		};
		
		/* PRIVATE METHODS */
		function iLog(Place, Message, Type, Silent) {
			log.Add('validator.' + Place, Message, Type, Silent);
		}
		function addValidatorTo(element, fv, cfgObj) {
			try {
				var el = $(element),
					val = el.attr('validator');
				if (!val)
					return;

				var name = /[^.(]*/.exec(val)[0];
				if (!name)
					return;

				if (validator.Default[name])
					val = 'MP.Validator.Default.' + val;

				var cfg = eval(val);
				fv.addField(el, cfg);

				if (cfg.isRequired) {
					el.addClass(cfgObj.requiredClass);
				};
				if (cfg.isCurrency) {
					el.autoNumeric('init', cfgObj.currency);
				};
				if (cfg.isDate) {
					el.datepicker("option", "minDate", cfg.validators.date.min);
					el.datepicker("option", "maxDate", cfg.validators.date.max);
					el.datepicker("option", "onSelect", function(date, dp) {
						var el = $(this);
						fv.resetField(el);
					});
				};
			} catch (err) {
				iLog("addValidatorTo", 'Validator: ' + err.message, log.Type.Error);
			}
		}
		function addRequired(cfg, required, message) {
			if (required) {
				$.extend(cfg.validators, {
					notEmpty: {
						message: message
					}
				});
			} else
				delete cfg.validators.notEmpty;
			cfg.isRequired = required;

			return cfg;
		}
		function addRequiredSelect(cfg, required, message) {
			if (required) {
				$.extend(cfg.validators, {
					callback: {
						callback: function (value, validator, field) {
							return (value != '-1');
						},
						message: message || 'Please make a selection.'
					}
				});
			} else
				delete cfg.validators.callback;
			cfg.isRequired = required;

			return cfg;
		}
		function ensureContainer(container) {
			container = container || '#bootstrapContent';
			
			return $(container);
		}
		function updateField(val1, val2, data) {
			if (val1 != val2) {
				data.element.val(val2);
				data.fv.resetField(data.element);
			}
		}
		function correctDate(e, data) {
			var val1 = data.element.val(),
				val2 = validator.Correct.date(val1);
			updateField(val1, val2, data);
		}
		function correctPhone(e, data) {
			var val1 = data.element.val(),
				val2 = validator.Correct.phone(val1);
			updateField(val1, val2, data);
		}
		function correctSSN(e, data) {
			var val1 = data.element.val(),
				val2 = validator.Correct.ssn(val1);
			updateField(val1, val2, data);
		}
		function correctFEIN(e, data) {
			var val1 = data.element.val(),
				val2 = validator.Correct.fein(val1);
			updateField(val1, val2, data);
		}
		function findParentValidator(element) {
			var el = $(element),
				fv = el.data('formValidation');
			if (fv)
				return fv;

			var parents = el.parents();
			for (var i = 0; i < parents.length; i++) {
				el = $(parents[i]);
				fv = el.data('formValidation');
				if (fv)
					return fv;
			}
		}
		function getValidatorsOf(container, validatorCB) {
			var cont = ensureContainer(container),
				fv = findParentValidator(cont);
			if (!fv || !validatorCB)
				return;
			
			var inputs;
			if (cont.is(":input"))
				inputs = cont;
			else
				inputs = cont.find(':input');
			
			inputs
				.not('button')
				.each(function(i, input) {
					input = $(input);

					var name = input.attr('name') || input.attr('id');
					if (!name)
						return;

					var cfg = fv.options.fields[name];
					validatorCB(fv, name, input, cfg);
				});
		}

		return {
			/* PUBLIC PROPERTIES */

			/* PUBLIC METHODS */
			Initialize : function (cfgObj) {
				$.extend(config, cfgObj);
			},
			Add : function (container, cfgObj) {
				try {
					var cont = ensureContainer(container);

					// Customize default validation
					cfgObj = $.extend({}, config, cfgObj);
					cont.formValidation(cfgObj);
					var fv = cont.data('formValidation');

					// Add default core validators
			        cont.find('[validator]')
						.each(function(i, element) {
				        	addValidatorTo(element, fv, cfgObj);
				        });

			        return fv;
				} catch (err) {
					iLog("Add", err, log.Type.Error);
				}
			},
			Remove : function (container) {
				try {
					var cont = ensureContainer(container),
						fv = findParentValidator(cont);
					if (fv)
						fv.destroy();
					cont.find('.' + config.requiredClass).removeClass(config.requiredClass);

					return cont;
				} catch (err) {
					iLog("Remove", err, log.Type.Error);
				}
			},
			Reset : function (container) {
				try {
					var cont = ensureContainer(container),
						fv = findParentValidator(cont);
					if (fv)
						fv.resetForm();
			        
			        return fv;
				} catch (err) {
					iLog("Reset", err, log.Type.Error);
				}
			},
			RequiredFields : function (enable, selector, blankMsg) {
				var ret = $();
				try {
					getValidatorsOf(selector, function(fv, name, input, cfg) {
						if (cfg) {
							fv.removeField(input);
							if (input.is("select"))
								addRequiredSelect(cfg, enable, blankMsg);
							else
								addRequired(cfg, enable, blankMsg);
							fv.addField(input, cfg);
							ret = ret.add(input);
						} else {
							if (enable) {
								if (input.is("select"))
									fv.addField(input, validator.Default.select(blankMsg));
								else
									fv.addField(input, validator.Default.required(blankMsg));
								ret = ret.add(input);
							}
						}
						input.toggleClass(config.requiredClass, enable);
					});
				} catch (err) {
					iLog("RequiredFields", err, log.Type.Error);
				}
				return ret;
			},
			EnableFields : function (enable, selector, validatorName) {
				var ret = $();
				try {
					getValidatorsOf(selector, function(fv, name, input, cfg) {
						if (cfg) {
							fv.enableFieldValidators(name, enable, validatorName);
							ret = ret.add(input);
						}
					});
				} catch (err) {
					iLog("EnableFields", err, log.Type.Error);
				}
				return ret;
			},
			RemoveFields : function (selector) {
				var ret = $();
				try {
					getValidatorsOf(selector, function(fv, name, input, cfg) {
						if (cfg) {
							fv.resetField(name);
							fv.removeField(name);
							input.removeClass(config.requiredClass);
							ret = ret.add(input);
						}
					});
				} catch (err) {
					iLog("RemoveFields", err, log.Type.Error);
				}
				return ret;
			},
			ResetFields : function (selector) {
				var ret = $();
				try {
					getValidatorsOf(selector, function(fv, name, input, cfg) {
						if (cfg) {
							fv.resetField(name);
							ret = ret.add(input);
						}
					});
				} catch (err) {
					iLog("ResetFields", err, log.Type.Error);
				}
				return ret;
			},
			AddFields : function (selector, cfgObj) {
				var ret = $();
				try {
					// Customize default validation
					cfgObj = $.extend({}, config, cfgObj);

					getValidatorsOf(selector, function(fv, name, input, cfg) {
						addValidatorTo(input, fv, cfgObj);
						ret = ret.add(input);
					});
				} catch (err) {
					iLog("AddFields", err, log.Type.Error);
				}
				return ret;
			},
			InProgress : function () {
				return inProgress;
			},
			Validate : function (container, cfgObj) {
				try {
					var cont = ensureContainer(container),
						fv = cont.data('formValidation');
					if (!fv)
						fv = validator.Add(cont, cfgObj);
					else
						$.extend(fv.options, cfgObj);

					if (!fv)
						return [];

					inProgress = true;
					validator.Reset(cont);
					fv.validateContainer(cont);
					inProgress = false;
					var errors = fv.getMessages();

					return errors;
				} catch (err) {
					iLog("Validate", err, log.Type.Error);
				}
			},
			Correct : {
				date : function(value) {
					var val = value.replace(/[^0-9]/g, "/"); // replace any separators with /
					
					if (val.indexOf("/") == -1) {
						switch (val.length) {
							case 4: // 7403 - 742003 - 7/4/2003
								val = val.insert([2], "20");
								val = val.insert([1, 2], "/");
								break;
							case 5: // 72403 - 7242003 - 7/24/2003
								val = val.insert([3], "20");
								val = val.insert([1, 3], "/");
								break;
							case 6: // 742003 - 7/4/2003
								val = val.insert([1, 2], "/");
								break;
							case 7: // 7242003 - 7/24/2003
								val = val.insert([1, 3], "/");
								break;
							case 8: // 07242003 - 07/24/2003
								val = val.insert([2, 4], "/");
								break;
							default:
								val = value;
						}
					} else
						val = value;

					return val;
				},
				phone : function(value) {
					var val = value.replace(/[^0-9]/g, "-"); // replace any separators with -
					
					if (val.indexOf("-") == -1) {
						switch (val.length) {
							case 10: // 1002003000 - 100-200-3000
								val = val.insert([3, 6], "-");
								break;
							default:
								val = value;
						}
					} else
						val = value;

					return val;
				},
				ssn : function(value) {
					var val = value.replace(/[^0-9]/g, ""); // remove any non-numeric characters
					
					if (val.length == 9)
						val = val.substring(0, 3) + "-" + val.substring(3, 5) + "-" + val.substring(5);
					else
						val = value;

					return val;
				},
				fein : function(value) {
					var val = value.replace(/[^0-9]/g, ""); // remove any non-numeric characters
					
					if (val.length == 9)
						val = val.substring(0, 2) + "-" + val.substring(2);
					else
						val = value;

					return val;
				}

			},
			Default : {
				required : function (blankMsg) {
					var cfg = {
						validators: {}
					};
					return addRequired(cfg, true, blankMsg);
				},
				date : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						isDate: true,
						validators: {
							date: {
								format: 'MM/DD/YYYY',
								message: invalidMsg || 'Invalid date.',
								onError: correctDate
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The date is required.');
				},
				dateAfter : function (date, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						isDate: true,
						validators: {
							date: {
								format: 'MM/DD/YYYY',
								min: date,
								message: invalidMsg || 'The date must be after ' + date + '.',
								onError: correctDate
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The date is required.');
				},
				dateBefore : function (date, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						isDate: true,
						validators: {
							date: {
								format: 'MM/DD/YYYY',
								max: date,
								message: invalidMsg || 'The date must be before ' + date + '.',
								onError: correctDate
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The date is required.');
				},
				dateBetween : function (date1, date2, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						isDate: true,
						validators: {
							date: {
								format: 'MM/DD/YYYY',
								min: date1,
								max: date2,
								message: invalidMsg || 'The date must be between ' + date1 + ' and ' + date2 + '.',
								onError: correctDate
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The date is required.');
				},
				select : function (blankMsg) {
					var cfg = {
						validators: {}
					};
					return addRequiredSelect(cfg, true, blankMsg);
				},
				zip : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							zipCode: {
								country: 'US',
								message: invalidMsg || 'Invalid zip code.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The zip code is required.');
				},
				phone : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /\b\d{3}[-]\d{3}[-]\d{4}\b/,
								message: invalidMsg || 'Invalid phone number.',
								onError: correctPhone
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The phone number is required.');
				},
				same : function (field, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							identical: {
								field: field,
								message: invalidMsg || 'Not matching fields.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				different : function (fields, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							different: {
								field: fields,
								message: invalidMsg || 'Matching fields.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				equals : function (value, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: new RegExp('^' + value + '$'),
								message: invalidMsg || 'Entered value is incorrect.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				regexp : function (pattern, modifiers, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: new RegExp(pattern, modifiers),
								message: invalidMsg || 'Entered value is incorrect.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				email : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
								message: invalidMsg || 'Invalid email address.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The email address is required.');
				},
				emailList : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /^(([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,63}))((;(([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,63})))*)(;{0,1})$/,
								message: invalidMsg || 'Invalid email list.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The email list is required.');
				},
				time : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /^(0?[1-9]|1[012])(:[0-5]\d) [APap][mM]$/,
								message: invalidMsg || 'Invalid time.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The time is required.');
				},
				currency : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						isCurrency: true,
						validators: {
							callback: {
								callback: function (value, validator, field) {
									var val = value.replace(/[^0-9\.-]/g, '');
									return parseFloat(val);
								},
								message: invalidMsg || 'Invalid amount.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The amount is required.');
				},
				ssn : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /^[0-9]{3}[\- ][0-9]{2}[\- ][0-9]{4}$/,
								message: invalidMsg || 'Invalid social security number.',
								onError: correctSSN
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The social security number is required.');
				},
				fein : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							regexp: {
								regexp: /^[0-9]{2}[\- ][0-9]{7}$/,
								message: invalidMsg || 'Invalid federal employer identification.',
								onError: correctFEIN
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The federal employer identification is required.');
				},
				state : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							callback: {
								callback: function (value, validator, field) {
									var val = value.toUpperCase();
									field.val(val);

									if (!val || val == "INT")
										return true;

									var re = /[A-Z]{2}/;
									if (!re.test(val) || val.length != 2)
										return false;
									
									var states = "AL AK AZ AR CA CO CT DC DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY PR VI GU";
									re = new RegExp(val, '');

									return states.search(re) > -1;
								},
								message: invalidMsg || 'Invalid state.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || 'The state is required.');
				},
				driverLicense : function (state, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							callback: {
								callback: function (value, validator, field) {
									if (!value)
										return true;

									// state can be either 2 character string, jQuery object or selector for input or select, or callback function
									var st = '';
									if (utils.IsString(state) && state.length == 2)
										st = state;
									else {
										if (utils.IsFunction(state))
											st = state(value, field);
										else
											st = $(state).val();
									};
									st = st.toUpperCase();
									
									var stObj = dlStates[st];
									if (!stObj)
										stObj = dlStates.default;
									var re = new RegExp(stObj.rule, 'i');

									return re.test(value);
								},
								message: invalidMsg || "Invalid driver's license number."
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg || "The driver's license number is required.");
				},
				vin : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							vin: {
								message: invalidMsg || 'Invalid vehicle identification number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				creditCard : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							creditCard: {
								message: invalidMsg || 'Invalid credit card number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				cvv : function (ccField, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							cvv: {
								creditCardField: ccField,
								message: invalidMsg || 'Invalid CVV number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				rtn : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							rtn: {
								message: invalidMsg || 'Invalid routing transit number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				int : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							integer: {
								message: invalidMsg || 'Invalid integer number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				intLessThan : function (int, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							integer: {
								message: invalidMsg || 'Invalid integer number.'
							},
							lessThan: {
								value: int,
								inclusive: false,
								message: invalidMsg || 'The integer number must be less than %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				intGreaterThan : function (int, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							integer: {
								message: invalidMsg || 'Invalid integer number.'
							},
							greaterThan: {
								value: int,
								inclusive: false,
								message: invalidMsg || 'The integer number must be greater than %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				intBetween : function (min, max, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							integer: {
								message: invalidMsg || 'Invalid integer number.'
							},
							between: {
								min: min,
								max: max,
								message: invalidMsg || 'The integer number must be between %s and %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				float : function (invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							numeric: {
								message: invalidMsg || 'Invalid floating-point number.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				floatLessThan : function (float, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							lessThan: {
								value: float,
								inclusive: false,
								message: invalidMsg || 'The floating-point number must be less than %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				floatGreaterThan : function (float, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							greaterThan: {
								value: float,
								inclusive: false,
								message: invalidMsg || 'The floating-point number must be greater than %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				},
				floatBetween : function (float1, float2, invalidMsg, isRequired, blankMsg) {
					var cfg = {
						validators: {
							between: {
								min: float1,
								max: float2,
								message: invalidMsg || 'The floating-point number must be between %s and %s.'
							}
						}
					};
					return addRequired(cfg, isRequired, blankMsg);
				}
			}
		}
	}



	// Debugging tools
	var tools = new function () {
		try {

			/* PRIVATE PROPERTIES */
			var tbDiv = $(),
				lastButton,
				lastXML,
				wfButton, wfSecs,
				origTitle = document.title,
				reqList, watchList, ajaxList, logList,
				reqListWnd, watchListWnd, ajaxListWnd, logListWnd;

			var config = {
					Editor : {
						ace : {
							enabled : true,
							theme : "chrome",
							codeTips : false,
							wordWrap : false
						},
						property : {
							pinned : false
						},
						toolBars : {
							developer : {
								width : 0,
								position : {
									left : 10,
									top : 10
								}
							}
						},
						tabs : {
							logging : {
								pinned : false,
								viewStyle : "float",
								position : {
									left : "center",
									top : "middle"
								},
								size : {
									width : 600,
									height : 400
								}
							},
							reqList : {
								pinned : false,
								filter : "",
								viewStyle : "float",
								showAll : false,
								filterVars : false,
								position : {
									left : "center",
									top : "middle"
								},
								size : {
									width : 600,
									height : 400
								}
							},
							watchList : {
								pinned : false,
								filter : "",
								viewStyle : "float",
								position : {
									left : "center",
									top : "middle"
								},
								size : {
									width : 600,
									height : 400
								}
							},
							ajax : {
								pinned : false,
								viewStyle : "float",
								position : {
									left : "center",
									top : "middle"
								},
								size : {
									width : 600,
									height : 400
								}
							}
						}
					},
					ScriptFunctions : []
				};

			/* PRIVATE METHODS */
			function iLog(Place, Message, Type, Silent) {
				log.Add("Tools." + Place, Message, Type, Silent);
			}
			function UpdateButton(section, button, condition, definition, onClick) {
				
				var sect = 'toolbarSection' + section,
					tbSect = tbDiv.find('#' + sect);
				if (!tbSect.length)
					tbSect = $('<div id="' + sect + '" class="toolbarSection">').appendTo(tbDiv);
				
				var btn = tbSect.find('#' + button);
				if (condition) {
					if (!btn.length) {
						btn = $(definition);
						if (lastButton)
							lastButton.after(btn);
						else
							tbSect.append(btn);
						if (onClick)
							btn.bind("click", onClick);
					};
					lastButton = btn;
				} else
					btn.remove();
			}
			function removeToolbar() {
				tbDiv.remove();
				lastButton = null;
			}
			function initToolbar() {
				iLog("initToolbar", "Called");

				if (tbDiv.length) {
					if (tbDiv.is(':visible'))
						return;
					else
						removeToolbar();
				}
				
				tbDiv = $('#DevToolBar');
				if (!tbDiv.length) {
					tbDiv = $('<div id="DevToolBar" class="verticalToolbar"/>');
				    $('#bootstrapContent').before(tbDiv);
				}
				
				tbDiv.affix({
					offset: {
						top: $('.header').height()
					}
				});
			}
			function loadWindow(wnd, clearCB, loadedCB) {
				var fn = wnd.addEventListener || wnd.attachEvent,
					id = setInterval(waitForTools, 200);
				fn('beforeunload', clearCB);

				function waitForTools() {
					if (wnd.MP && wnd.MP.Tools) {
						clearInterval(id);
						loadedCB(wnd.MP.Tools);
					}
				}
			}
			function showLogging(activate) {
				if (!config.loggingEnabled)
					return;

				function clear() {
					logList = null;
					logListWnd = null;

					log.Set(null);
				}
				function load(tools) {
					logList = tools.LogList;
					var cfg = config.Editor.tabs.logging;
					cfg.enabled = config.loggingEnabled;
					logList.Initialize(cfg);
					logList.Load(log.CachedLogs());
					log.Set(logList);
				}

				if (logListWnd && logListWnd.focus) {
					logListWnd.focus();
				} else {
					logListWnd = comm.OpenWindow("../../debug-log.html?id=" + comm.SessionID, 'Log Viewer - ' + comm.SessionID);
					loadWindow(logListWnd, clear, load);
				}
			}
			function showReqList() {
				if (!config.reqlistEnabled)
					return;

				function clear() {
					reqList = null;
					reqListWnd = null;
				}
				function load(tools) {
					reqList = tools.ReqList;
					var cfg = config.Editor.tabs.reqList;
					cfg.enabled = config.reqlistEnabled;
					reqList.Initialize(cfg, lastXML);
				}

				if (reqListWnd && reqListWnd.focus) {
					reqListWnd.focus();
				} else {
					reqListWnd = comm.OpenWindow("../../debug-rl.html?id=" + comm.SessionID, 'ReqList Viewer - ' + comm.SessionID);
					loadWindow(reqListWnd, clear, load);
				}
			}
			function showWatchList() {
				if (!config.watchlistEnabled)
					return;

				function clear() {
					watchList = null;
					watchListWnd = null;
				}
				function load(tools) {
					watchList = tools.WatchList;
					var cfg = config.Editor.tabs.watchList;
					cfg.enabled = config.watchlistEnabled;
					watchList.Initialize(cfg, lastXML);
				}

				if (watchListWnd && watchListWnd.focus) {
					watchListWnd.focus();
				} else {
					watchListWnd = comm.OpenWindow("../../debug-wl.html?id=" + comm.SessionID, 'WatchList Viewer - ' + comm.SessionID);
					loadWindow(watchListWnd, clear, load);
				}
			}
			function showAjax(activate) {
				if (!config.ajaxEnabled)
					return;

				var wnd = comm.OpenWindow("../../debug-com.html?id=" + comm.SessionID, 'Communication Viewer');
				setTimeout(function() {
					ajaxList = wnd.MP.Tools.AjaxList;
					if (!ajaxList)
						return;
					
					var cfg = config.Editor.tabs.ajax;
					cfg.enabled = config.watchlistEnabled;
					ajaxList.Initialize(cfg, lastXML);
				}, 2000);
			}

			function saveConfiguration() {
				var SaveAndSend = function (saveDefault) {
					dlg.dialog("close");
					
					// Update the configuration object
					var c = config.Editor;
					var doc = $(document);
					var UpdateDbgWndCfg = function(cfg, div) {
						if (div.data('lastLeft') && div.data('lastTop')) {
							cfg.position.left = div.data('lastLeft');
							cfg.position.top = div.data('lastTop');
							cfg.size.width = Utilities.ToNumber(div.parent().width());
							cfg.size.height = Utilities.ToNumber(div.parent().height());
						};
					};
					
					var d = tbDiv;
					if (d.length) {
						c.toolBars.developer.position.left = d.data('lastLeft');
						c.toolBars.developer.position.top = d.data('lastTop');
						c.toolBars.developer.width = Utilities.ToNumber(d.width());
					}
					d = $('#RuleToolbar');
					if (d.length) {
						c.toolBars.process.position.left = d.data('lastLeft');
						c.toolBars.process.position.top = d.data('lastTop');
						c.toolBars.process.width = Utilities.ToNumber(d.width());
					}
					d = $('#ComponentToolbar');
					if (d.length) {
						c.toolBars.page.position.left = d.data('lastLeft');
						c.toolBars.page.position.top = d.data('lastTop');
						c.toolBars.page.width = Utilities.ToNumber(d.width());
					}
					d = $('#BootstrapToolbar');
					if (d.length) {
						c.toolBars.bootstrap.position.left = d.data('lastLeft');
						c.toolBars.bootstrap.position.top = d.data('lastTop');
						c.toolBars.bootstrap.width = Utilities.ToNumber(d.width());
					}
					d = $('#LoggingDiv');
					if (d.length) {
						UpdateDbgWndCfg(c.tabs.logging, d);
					}
					d = $('#ReqListDiv');
					if (d.length) {
						UpdateDbgWndCfg(c.tabs.reqList, d);
					}
					d = $('#WatchListDiv');
					if (d.length) {
						UpdateDbgWndCfg(c.tabs.watchList, d);
					}
					d = $('#AjaxDiv');
					if (d.length) {
						UpdateDbgWndCfg(c.tabs.ajax, d);
					}
					
					// Convert the configuration object to string
					var data = 'Cfg="Editor":';
					if (saveDefault)
						data += '{}';
					else
						data += encodeURIComponent(JSON.stringify(c));
					var url = "admintabs.max?action=SaveConfig";
					
					// Send to the server
					comm.Post({url: url, data: data});
				};

				// This dialog is being reused and so should be created only once!
				var dlg = $('#SaveConfigurationDlg');
				if (!dlg.length) {
					dlg = $('<div id="SaveConfigurationDlg"></div>');
					dlg.html('<p>You can either save your current configuration or reset to the default settings.<p/><p>In order to see the default setting you must re-login.</p>');
					
					var btns = {
						'Reset to default' : function () {
							SaveAndSend(true);
						},
						'Save current' : function () {
							SaveAndSend(false);
						}
					};					
					dlg.dialog({
						width : 370,
						autoOpen : false,
						closeOnEscape : true,
						resizable : false,
						modal : true,
						buttons : btns,
						dialogClass : "clientDialog",
						title : "Save User Preferences"
					});
				};
				dlg.dialog("open");
			}
			function pingWorkflow() {
				if (!comm.SessionID)
					return;

				comm.Post("IconTray.max?action=workflow", function (IconColor) {
					if (IconColor != "none")
						wfButton.attr("src", "../../images/32px-Crystal_Clear_app_access_" + IconColor + ".png");
					else
						wfButton.css("display", "none");
				});
				
				setTimeout(pingWorkflow, wfSecs * 1000);
			}
			function shortcuts(inEditor) {
				iLog("shortcuts", "Called");

				var m = window.Mousetrap;
				if (!m)
					return;

				function cancelCB(event, combination) {
					log.Debug(combination + ' canceled!');
					return false;
				};

				m.reset();

				m.bind('backspace', cancelCB);
				m.bind('ctrl+r', cancelCB);
				m.bind('ctrl+f5', cancelCB);
				m.bind('f5', cancelCB);
			}
			
			return {
			
				/* PUBLIC PROPERTIES */
				description: "Debugging tools",
				Initialized : false,
				Enabled : false,
				
				/* PUBLIC METHODS */
				Initialize : function (cfgObj) {
					try {
						cfgObj = cfgObj || {};
						$.extend(true, config, cfgObj);
						
						shortcuts();
						tools.Enabled = true;
						tools.Initialized = true;
						tools.UpdateToolbar();
					} catch (err) {
						iLog("Initialize", err, log.Type.Error);
					}
				},
				Update : function (data) {
					// Cache last valid RL
					var ir = comm.InitialRequest;
					if (ir)
						lastXML = data;

					if (reqList)
						reqList.Load(data, ir);
					if (watchList)
						watchList.Load(data, ir);
					if (ajaxList)
						ajaxList.Load(data, ir);
				},
				GetLastXML : function () {
					return lastXML;
				},
				UpdateConfig : function (cfgObj) {
					$.extend(true, config, cfgObj);
				},
				UpdateToolbar : function () {
					try {
						if (!tools.Initialized)
							return;
						if (config.editorEnabled)
							initToolbar();
						else {
							removeToolbar();
							return;
						}

						var b;
						b = config.loggingEnabled;
						UpdateButton('1', 'dtbLog', b, '<img id="dtbLog" title="Open a Log Viewer" src="../../images/dev-logging.png" />', showLogging);

						b = config.reqlistEnabled;
						UpdateButton('1', 'dtbRL', b, '<img id="dtbRL" title="Open a ReqList Viewer" src="../../images/dev-reqlist.png" />', showReqList);
						
						b = config.watchlistEnabled;
						UpdateButton('1', 'dtbWL', b, '<img id="dtbWL" title="Open a WatchList Viewer" src="../../images/dev-watchlist.png" />', showWatchList);
						
						b = config.ajaxEnabled;
						//UpdateButton('1', 'dtbAjax', b, '<img id="dtbAjax" title="Open an Ajax Viewer" src="../../images/dev-ajax.png" />', showAjax);
						
						b = JSON && JSON.stringify;
						//UpdateButton('1', 'dtbCfg', b, '<img id="dtbCfg" title="Save current configuration and layout" src="../../images/dev-config.png" />', saveConfiguration);
						
						b = true;
						UpdateButton('1', 'dtbVer', b, '<img id="dtbVer" title="Show version" src="../../images/dev-version.png" />', function() { MP.ShowVersion('Client Version: ') });
					} catch (err) {
						iLog("UpdateToolbar", err, log.Type.Error);
					}
				},
				ShowVrmName : function (vrmName) {
					if (!tools.Initialized || !config.editorEnabled || !vrmName)
						return;
					
					var s = vrmName.toUpperCase();
					if (config.editorEnabled)
						document.title = s + '.VRM';
				},
				AceEnabled : function () {
					return !Browser.IsMSIE() && window.ace && config.Editor.ace.enabled;
				},
				EditorEnabled : function() {
					return config.editorEnabled;
				},
				InitWorkflow : function(button, repeatSeconds) {
					wfButton = $(button);
					wfSecs = repeatSeconds || 300;
					if (wfButton.length)
						pingWorkflow();
				}
			}
		
		} catch (err) {
			iLog("Main", err, log.Type.Error);
		}
	};



	// Core messaging!
	var webSocket = new function() {
		try {
			/* PRIVATE PROPERTIES */
			var _webSocket,
				_webSockets = [],
				_watchDog,
				_url = utils.ParseURL();
				
			var _config = {
				host: _url.hostname,
				port: 5711,
				autoReconnectMS: 30000,
				systemApplication: '',
				ssl: false
			};

			/* PRIVATE METHODS */
			function iLog(Place, Message, Type, Silent) {
				log.Add("WebSocket." + Place, Message, Type, Silent);
			}
			function WebSocketObj(name) {
				this.app = name.toLowerCase();
				this.onMessage;
				this.onOpen;
				this.onClose;
				this.onError;
			}
			function Message(name, msg) {
				this.app = name.toLowerCase();
				this.text = msg;
			}
			function executeCB(callback, data, webSocketObj) {
				if (!callback)
					return;

				try {
					callback(data, webSocketObj);
				} catch (err) {
					iLog('executeCB', err, log.Type.Error, true);
				};
			}
			function getMessage(data) {
				var msg = new Message('system', '');
				try {
					msg = $.parseJSON(data);
					msg.app = msg.app.toLowerCase();
				} catch (err) {
					msg.text = data;
				};

				return msg;
			}
			function getConfig(msg) {
				var cfg = msg.config || '{}';
				try {
					cfg = cfg.replace(/&(quot);/g, '"');
					cfg = $.parseJSON(cfg);
				} catch (err) {
					cfg = {};
					iLog('getConfig', err, Log.Type.Error, true);
				};

				return cfg;
			}
			function handleSysMsg(msg) {
				var cfg = getConfig(msg),
					show = cfg.showAs || 'alert-dlg';
				
				show = show.toLowerCase();
				cfg.message = msg.text || cfg.message;
				if (!cfg.message)
					return;

				switch (show) {
					case 'custom-dlg':
						cfg.title = cfg.title || 'System Message';
						dialog.Custom(cfg);
						break;
					case 'confirm-dlg':
						cfg.title = cfg.title || 'Confirm';
						cfg.callback = function(answer) {
							msg = $.extend(msg, {
								//id: comm.SessionID,
								answer: answer
							});
							webSocket.Send(msg.app, msg);
						};
						dialog.Confirm(cfg);
						break;
					case 'prompt-dlg':
						cfg.title = cfg.title || 'Prompt';
						cfg.callback = function(answer) {
							msg = $.extend(msg, {
								//id: comm.SessionID,
								answer: answer
							});
							webSocket.Send(msg.app, msg);
						};
						dialog.Prompt(cfg);
						break;
					case 'info-ntf':
						cfg.delay = cfg.delay || 0;
						notify.Info(cfg, cfg);
						break;
					case 'success-ntf':
						cfg.delay = cfg.delay || 0;
						notify.Success(cfg, cfg);
						break;
					case 'warning-ntf':
						cfg.delay = cfg.delay || 0;
						notify.Warning(cfg, cfg);
						break;
					case 'danger-ntf':
						cfg.delay = cfg.delay || 0;
						notify.Danger(cfg, cfg);
						break;
					default:
						cfg.title = cfg.title || 'Alert';
						dialog.Alert(cfg);
				};

				return true;
			}
			function setWatchDog() {
				if (_watchDog)
					return;

				watchDog();

				_watchDog = setInterval(watchDog, _config.autoReconnectMS || 30000);
			}
			function watchDog() {
				if (_webSocket || !webSocket.Count() || !comm.SessionOK())
					return;

				iLog('Reconnecting', webSocket.Count() + ' sockets');

				var protocol = _config.ssl ? 'wss://' : 'ws://';

				_webSocket = new WebSocket(protocol + _config.host + ':' + _config.port + '/sgc/auth/url/' + comm.SessionID + '/H');
				_webSocket.onopen = function(evt) {
					if (!comm.SessionOK())
						return;
					
					$.each(_webSockets, function() {
						executeCB(this.onOpen, evt, this);
					});
				};
				_webSocket.onclose = function(evt) {
					if (!comm.SessionOK())
						return;

					$.each(_webSockets, function() {
						executeCB(this.onClose, evt, this);
					});

					_webSocket = null;
				};
				_webSocket.onmessage = function(evt) {
					if (!comm.SessionOK())
						return;

					var msg = getMessage(evt.data)
					$.each(_webSockets, function() {
						if (msg.app == this.app)
							executeCB(this.onMessage, msg, this);
					});
				};
				_webSocket.onerror = function(evt) {
					if (!comm.SessionOK() || !evt.data)
						return;

					var msg = getMessage(evt.data);
					$.each(_webSockets, function() {
						if (msg.app == this.app)
							executeCB(this.onError, msg, this);
					});
				};
			}
			function findByName(name) {
				name = name.toLowerCase();
				var idx = -1;
				$.each(_webSockets, function(index, item) {
					if (item.app == name)
						idx = index;
				});
				
				return idx;
			}
			function closeAll() {
				_webSocket.close();
				_webSocket = null;
				_webSockets = []; // Comment out to test closing and reconnecting the socket
			}
			
			return {
				
				Initialize: function(cfg) {
					$.extend(_config, cfg);

					// Make host as browser if not present
					if (!_config.host)
						_config.host = _url.hostname;

					if (_config.systemApplication)
						webSocket.Add(_config.systemApplication, {onMessage: handleSysMsg});
				},
				Remove: function(name) {
					if (!name)
						return;
					
					var idx = findByName(name);
					if (idx > -1) {
						iLog('Removing', name);
						_webSockets.splice(idx, 1);
						if (!webSocket.Count())
							closeAll();
					};
				},
				Count: function() {
					return _webSockets.length;
				},
				Find: function(name) {
					if (!name)
						return;
					
					var idx = findByName(name);
					if (idx > -1)
						return _webSockets[idx];
				},
				Close: function(name) {
					try {
						if (name) {
							iLog('Closing', name + ' socket');
							webSocket.Remove(name);
						} else {
							iLog('Closing', webSocket.Count() + ' sockets');
							closeAll();
						}
					} catch (err) {
						iLog('Close', err, log.Type.Error, true);
					}
				},
				Send: function(name, data) {
					try {
						if (!name)
							return;
						
						var ws = webSocket.Find(name),
							msg = new Message(name);
						if (ws) {
							iLog('Send', 'to ' + name);

							if (utils.IsString(data))
								msg.text = data;
							else
								$.extend(msg, data);

							_webSocket.send(JSON.stringify(msg));
						};
						
						return ws;
					} catch (err) {
						iLog('Send', err, log.Type.Error, true);
					}
				},
				Add: function(name, cfg) {
					try {
						if (!name)
							return;
						
						var ws = webSocket.Find(name);
						if (!ws) {
							ws = new WebSocketObj(name, cfg);
							$.extend(ws, cfg);
							_webSockets.push(ws);
							iLog('Added', name + ' (' + webSocket.Count() + ')');
						};
						
						setWatchDog();
						
						return ws;
					} catch (err) {
						iLog('Add', err, log.Type.Error, true);
					}
				}
			};
		} catch (err) {
			iLog("Main", err, log.Type.Error);
		}
	};



	// Publish private core objects:
	mp.Utils = utils;
	mp.Notify = notify;
	mp.Dialog = dialog;
	mp.Log = log;
	mp.Comm = comm;
	mp.Script = script;
	mp.Validator = validator;
	mp.Tools = tools;
	mp.WebSocket = webSocket;
	window.MP = mp;

	// We are fully loaded!
	mp.Initialize();

	//addToHomescreen.removeSession(); // debug
	addToHomescreen({
		//debug: 'ios', // debug
		appID: 'stingray.addtohome',
		skipFirstVisit: true, //false // debug
		maxDisplayCount: 1
	});

}) (window, document, jQuery);
